#!/bin/csh -f

grep -e "{\S\+\s\+\S\+}" clk_list.txt | sed -e "s/\(\S\+\)\s\+.*{\(\S\+\)}\s*/:\1::::\2/g" > clk_list_clean.txt
