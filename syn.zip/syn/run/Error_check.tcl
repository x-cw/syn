#! /bin/tcsh -f
grep --color -rn -m 15 ^Error *_syn.log
grep --color -rn -m 10 Cannot *_syn.log
grep --color -irn -m 10 "Can't" *_syn.log
grep --color -irn -m 10 Unable *_syn.log
grep --color -irn -m 10 unresolved *_syn.log
grep --color -irn -m 10 "timing loop" *_syn.log
grep --color -irn -m 10 "PG netlist mode" *_syn.log
grep --color -irn -m 10 VIOLATED reports/*worst_timing.rpt
grep --color -irn -m 5 GTECH nets/*.v 
