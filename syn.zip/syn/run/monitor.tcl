#!/usr/bin/tclsh
#
set TOP_NAME [lindex $argv 0]
set TOP_NAME1 [lindex $argv 1]
#puts "TOP_NAME: $TOP_NAME"

set syn_log  ${TOP_NAME}_syn.log
#puts "syn_log: $syn_log"
set user_name [exec whoami]
after 5000
set ram_gen [exec sh -c {ps -aux | grep dc_shell | awk '{print $1 "_" $13 "_" $NF}'}]
#set log_gen [exec sh -c "awk '/^Warning/ {print $0}; /^Error/ {print $0}' $syn_log"] 
#exec sh -c {awk '/^Warning/ {print $0}; /^Error/ {print $0}' $syn_log > err_02.log}
exec sh -c {awk '/^Warning/ {print $0}; /^Error/ {print $0}' *_syn.log} > err_warn.log
#set ram_gen_12 [exec sh -c {ps -aux | grep yex | grep ram_gen.tcl | awk '{print $12}'}]
#puts "sh: $ram_gen "
#puts $lleng
set finish_flag 0;
while {$finish_flag == 0} {
set finish_flag  1
foreach ram_hit $ram_gen {
  #set ram_gen [exec sh -c {ps -aux | grep ram_gen.tcl | awk '{print $1 $11 $12}'}]
  set ram_gen [exec sh -c {ps -aux | grep dc_shell | awk '{print $1 "_" $13 "_" $NF}'}]
  #puts "ram_hit:$ram_hit"
  set des_file [format "%s_dc_shell_%s"  $user_name  $syn_log]
  #lappend log_gen [exec sh -c "awk '/^Warning/ {print $0}; /^Error/ {print $0}' $syn_log"]
 # exec sh -c {awk '/^Warning/ {print $0}; /^Error/ {print $0}' $syn_log >> err_02.log}
  exec sh -c {awk '/^Warning/ {print $0}; /^Error/ {print $0}' *_syn.log} > err_warn.log
  #puts "des_file: $des_file ram_hit: $ram_hit "
  set hit_string [lsearch -exact $ram_hit $des_file]
  #puts "Hit string bool: $hit_string"
  if {[expr $hit_string == 0]} { 
    set finish_flag 0;
   } 
  }
after 5000
}

if {$finish_flag == 1} {
puts "\n==============================================\n" 
puts " ********************************************\n"
puts "  Finished Collection for DC Information\n" 
puts "==============================================\n"
  
  }
