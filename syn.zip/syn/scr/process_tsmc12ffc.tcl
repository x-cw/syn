###############################################################################
# TSMC 12nm
###############################################################################
set LIB_PATH  [list \
              /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn12ffcllbwp6t16p96cpd_120a \
              /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn12ffcllbwp6t16p96cpdlvt_120a \
              /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn12ffcllbwp6t16p96cpdmb_120b \
              /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn12ffcllbwp6t16p96cpdmblvt_120b \
              /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn12ffcllbwp6t20p96cpd_120a \
              /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn12ffcllbwp6t20p96cpdlvt_120a \
              /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn12ffcllbwp6t20p96cpdmb_120b \
              /Foundry/ARM/tsmc12FFC/Standard_Cell/TSMCHOME/digital/Front_End/timing_power_noise/CCS/tcbn12ffcllbwp6t20p96cpdmblvt_120b \
              ../scr/libtodb_scr \
              ]

set_app_var search_path         [concat $search_path $LIB_PATH]
set_app_var synthetic_library   [list dw_foundation.sldb standard.sldb]

#--------- Logic library
set LIB_EXT             "db"

# define MEMORY DEFINE for the libaray
#set MEM_DEF_LIST        CNM_TSMC28HPC
if {![info exist USE_PWR_RPT]}      { set USE_PWR_RPT   0 } 
if {![info exist USE_MIXED_LIB]}    { set USE_MIXED_LIB 0 } 
if {![info exist USE_LIB_M40]}      { set USE_LIB_M40   1 } 


# Set target_library
#if { $USE_PWR_RPT == 1 } {
#    set_app_var target_library  [list \
	                                                tcbn12ffcllbwp6t16p96cpdssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t16p96cpdlvtssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t20p96cpdssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t20p96cpdlvtssgnp0p72vm40c_ccs.db \
							                            ]
#} else {
    #set_app_var target_library      [list  tcbn12hpcbwp35p140hvtssg0p81v0c.db]
#    set_app_var target_library  [list \
	                                                tcbn12ffcllbwp6t16p96cpdssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t16p96cpdlvtssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t20p96cpdssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t20p96cpdlvtssgnp0p72vm40c_ccs.db \
							                            ]
#}

set_app_var target_library  [list \
                                                        tcbn12ffcllbwp6t16p96cpdssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t16p96cpdlvtssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t16p96cpdmbssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t16p96cpdmblvtssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t20p96cpdssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t20p96cpdlvtssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t20p96cpdmbssgnp0p72vm40c_ccs.db \
                                                        tcbn12ffcllbwp6t20p96cpdmblvtssgnp0p72vm40c_ccs.db \
R1F_HD_D32_W188_M1_P188_ID203_lvt_ssgnp0p72vm40c.db \
R1F_HD_D64_W274_M1_P274_ID200_lvt_ssgnp0p72vm40c.db \
R1F_HD_D80_W128_M1_P8_ID100_lvt_ssgnp0p72vm40c.db \
R1F_UHD_D32_W128_M1_P128_ID201_lvt_ssgnp0p72vm40c.db \
R1F_UHD_D32_W128_M1_P128_ID202_lvt_ssgnp0p72vm40c.db \
R2F_UHD_D200_W128_M1_P128_ID204_lvt_ssgnp0p72vm40c.db \
R2F_UHD_D32_W128_M1_P128_ID205_lvt_ssgnp0p72vm40c.db \
R2F_HD_ram_1024x16_sp_ssgnp0p72vm40c.db \
R2F_HD_ram_1024x64_sp_ssgnp0p72vm40c.db \
R2F_UHD_rf_32x146_2p_ssgnp0p72vm40c.db \
R2F_UHD_rf_64x128_2p_ssgnp0p72vm40c.db \
ts1n12hpchvtb176x80m4sw_ssgnp0p72vm40c.db \
ts1n12hpchvtb2048x16m4sw_ssgnp0p72vm40c.db \
ts1n12hpchvtb256x128m4sw_ssgnp0p72vm40c.db \
ts1n12hpchvtb4096x16m4sw_ssgnp0p72vm40c.db \
ts1n12hpchvtb512x128m4sw_ssgnp0p72vm40c.db \
ts1n12hpchvtb512x28m4sw_ssgnp0p72vm40c.db \
ts1n12hpchvtb592x80m4sw_ssgnp0p72vm40c.db \
ts1n12hpcsvtb320x80m4sw_ssgnp0p72vm40c.db \
ts5n12hpchvta1024x32m8fw_ssgnp0p72vm40c.db \
ts5n12hpchvta112x128m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta112x140m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta112x20m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta112x32m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta128x16m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta128x32m2sw_ssgnp0p72vm40c.db \
ts5n12hpchvta128x40m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta128x60m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta128x80m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta128x93m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta144x64m2sw_ssgnp0p72vm40c.db \
ts5n12hpchvta144x80m2sw_ssgnp0p72vm40c.db \
ts5n12hpchvta16x140m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta16x20m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta192x68m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta192x80m2sw_ssgnp0p72vm40c.db \
ts5n12hpchvta256x32m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta256x40m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta256x80m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta288x32m4fw_ssgnp0p72vm40c.db \
ts5n12hpchvta32x128m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta32x140m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta32x16m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta32x20m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta32x22m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta32x40m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta32x42m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta32x80m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta48x128m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta512x32m4fw_ssgnp0p72vm40c.db \
ts5n12hpchvta512x64m4fw_ssgnp0p72vm40c.db \
ts5n12hpchvta56x32m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta576x32m8sw_ssgnp0p72vm40c.db \
ts5n12hpchvta64x128m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta64x32m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta64x40m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta64x42m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta64x80m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta72x80m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta80x128m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta80x140m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta80x20m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta80x30m4fw_ssgnp0p72vm40c.db \
ts5n12hpchvta80x32m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta80x32m2sw_ssgnp0p72vm40c.db \
ts5n12hpchvta80x50m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta80x80m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta88x32m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta96x140m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta96x20m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta96x80m2fw_ssgnp0p72vm40c.db \
ts5n12hpchvta96x80m2sw_ssgnp0p72vm40c.db \
ts6n12hpchvta128x128m2sw_ssgnp0p72vm40c.db \
ts6n12hpchvta128x36m2sw_ssgnp0p72vm40c.db \
ts6n12hpchvta128x80m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta144x80m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta152x80m2sw_ssgnp0p72vm40c.db \
ts6n12hpchvta16x128m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta176x128m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta192x100m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta192x120m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta192x140m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta192x32m2sw_ssgnp0p72vm40c.db \
ts6n12hpchvta192x40m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta192x80m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta208x80m2sw_ssgnp0p72vm40c.db \
ts6n12hpchvta24x32m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta24x80m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta256x128m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta256x80m2sw_ssgnp0p72vm40c.db \
ts6n12hpchvta288x128m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta288x32m2sw_ssgnp0p72vm40c.db \
ts6n12hpchvta32x128m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta32x17m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta48x5m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta512x144m2sw_ssgnp0p72vm40c.db \
ts6n12hpchvta64x128m2fw_ssgnp0p72vm40c.db \
ts6n12hpchvta80x128m2sw_ssgnp0p72vm40c.db \
                                                        ]
#                                                        rf_64x8_2p_ssgnp0p72vm40c.db \
#                                                        rf_16x24_2p_ssgnp0p72vm40c.db \
#                                                        ram_1024x16_dp_ssgnp0p72vm40c.db \
#                                                        ram_128x32_dp_ssgnp0p72vm40c.db \
#                                                        ram_16x8_sp_ssgnp0p72vm40c.db \
#                                                        ram_2048x24_dp_ssgnp0p72vm40c.db \
#                                                        ram_256x32_dp_ssgnp0p72vm40c.db \
#                                                        ram_512x128_sp_ssgnp0p72vm40c.db \
#                                                        ram_64x64_dp_ssgnp0p72vm40c.db \
#                                                        ]
#set_app_var link_library        [list * $target_library]
#set_app_var link_library        [concat $link_library $synthetic_library]
set_app_var link_library "* $target_library $synthetic_library"

#--------- Define MultiVth  Lib - if no db, comment
#modify by fengh
#if { $USE_MIXED_LIB == 1 }  {
#    set LVT_LIB tcbn12hpcbwp35p140lvtssg0p81v0c
#    set SVT_LIB tcbn12hpcbwp35p140ssg0p81v0c 
#    set HVT_LIB tcbn12hpcbwp35p140hvtssg0p81v0c
#}


#--------- MACRO library
#modify by fengh
#if {![file exists process_tsmc28hpc_macro.tcl]} {
#    source -e -v $scr_dir/process_tsmc28hpc_macro.tcl
#} else {
#    set MACRO_LIB ""
#}

#set_app_var link_library [concat $link_library $MACRO_LIB]                   
