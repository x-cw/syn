#=============================================================================
#
#       This confidential and proprietary software may be used only
#     as authorized by a licensing agreement from Chips&Media Inc.
#     In the event of publication, the following notice is applicable:
#
#                    (C) COPYRIGHT 2003 - 2011   CHIPS&MEDIA INC.
#                           ALL RIGHTS RESERVED
#
#       The entire notice above must be reproduced on all authorized
#     copies.
#
#=============================================================================
#
# File         : $Id: clock_constraints.tcl 145466 2018-04-24 11:18:07Z ethan.kim $
# Author(s)    : WAVE51x
# Modifier     : $LastChangedBy: ethan.kim $
# Description  : Clock and IO definition
#=============================================================================
#       CLOCK DEFINITION 
#------------------------------------------------


#-------------------------------------------------------------------------
# Constrinat Parameter
#source -e -v clock_constraints.tcl
#source -e -v delay_constraints.tcl


set cmd ""
foreach clk_a [get_object_name [all_clocks]] {
    foreach clk_b [get_object_name [all_clocks]] {
	    set cmd [concat $cmd set_false_path -from $clk_a -to $clk_b \;]
	    echo "CMD: set_false_path -from $clk_a -to $clk_b"
    }
}

remove_clock_groups -all -asynchronous
remove_clock_groups -all -logically_exclusive
remove_clock_groups -all -physically_exclusive

eval $cmd


#add async_fifo gray ptr maxdelay: clka_addr-> clkb_addr, clkb_addr -> clka_addr
#please conform the keywords in your design of the fifo async ptr(wadd and radd), if they are different, add them in the same way below
set gray_dffs [get_cells -filter "full_name =~ *async*dmid*reg* && is_sequential==true" -hier ]
append_to_collection gray_dffs [get_cells -filter "full_name =~ *FIFOFCTL*sample_fwp_reg* && is_sequential==true" -hier ]
append_to_collection gray_dffs [get_cells -filter "full_name =~ *fifo*inno_sync_cell*d_sync1* && is_sequential==true" -hier ]

foreach_in_collection dff ${gray_dffs} {
    set dff_name [get_attribute $dff full_name]
    set clk1_period [get_attribute [get_attribute [get_pins ${dff_name}/C*] clocks] period]
    #set clk2_period [get_attribute [get_attribute [get_attribute [get_pins [get_cells -of [get_pins [all_fanin -to [get_pins ${dff_name}/D*] -startpoints_only -flat] -filter "full_name =~ *addr* || full_name =~ *fifo*"]] -filter "is_clock == true"] full_name]clocks] period]
    set clk2_period [get_attribute [get_attribute [get_pins -of [get_object_name  [get_cells -of [get_pins [all_fanin -to [get_pins ${dff_name}/D*] -startpoints_only -flat] -filter "full_name =~ *addr* || full_name =~ *fifo*"]]] -filter {is_on_clock_network==true}] clocks] period]

    #echo "$dff_name $clk1_period $clk2_period" 
    set min_p 100 
    foreach period $clk1_period {
        #echo $period
        if {$min_p > $period} {set min_p $period}
    }
    foreach period $clk2_period {
        #echo $period
        if {$min_p > $period} {set min_p $period}
    }
    #echo $min_p
#    set src_dff [get_attribute [get_cells -of_objects [get_pins [all_fanin -to [get_pins ${dff_name}/D*] -startpoints_only -flat] -filter "full_name =~ *addr*" ]] full_name]
#    set_max_delay [expr {$min_p * 0.7}] -fr [get_pins $src_dff/Q*] -to [get_pins ${dff_name}/D*] -ignore_clock_latency
#    set_max_delay [expr {$min_p * 0.7}] -fr [get_pins [all_fanin -to [get_pins ${dff_name}/D*] -startpoints_only -flat] -filter "full_name =~ *addr*" ] -to [get_pins ${dff_name}/D*] -ignore_clock_latency
    set_max_delay [expr {$min_p * 0.7}] -fr [get_pins -of [get_cells -of [get_pins [all_fanin -to [get_pins ${dff_name}/D*] -startpoints_only -flat] -filter "full_name =~ *addr*" ]] -filter "full_name =~ *Q*"] -to [get_pins ${dff_name}/D*] -ignore_clock_latency
}


set_false_path -to   [all_outputs]
set_false_path -from [all_inputs]
