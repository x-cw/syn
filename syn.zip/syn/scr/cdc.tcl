set async_coef 1.0
#set async_coef 0.0
#set gray_coef  0.5
#set gray_keys "u._sync_r2w/wq._rptr u._sync_w2r/rq._wptr"
## set max delay to async paths 

remove_sdc
sh sed -n "/sdc_start/,/sdc_inout_start/p" ../sdc/scp_top_wrap.sdc > ../sdc/clk_only.sdc
sh sed -i "s/set_clock_groups/set_clock_groups -allow_paths/"  ../sdc/clk_only.sdc
sh sed -i 's/inst\\./inst_/g'  ../sdc/clk_only.sdc
exec sed -i {s/\[\([0-9]*\)\]/_\1_/g} ../sdc/clk_only.sdc

source -e -v ../sdc/clk_only.sdc

set_false_path -hold -from [all_clocks] -to [all_clocks]

report_clock -group > clock_group.rpt
sh grep "groups {.*}" clock_group.rpt > clock.rpt

set cmd ""
foreach clk_a [get_object_name [all_clocks]] {
    set period_a [get_attribute [get_clocks $clk_a] period]
    foreach clk_b [get_object_name [all_clocks]] {
    set clka " $clk_a "
    set clkb " $clk_b "
    set clock_file [open "./clock.rpt" r]
    while {[gets $clock_file line] != -1} {
      if {[string first $clka $line] != -1 && [string first $clkb $line] != -1 } {
        set is_same_group 1
        echo "$clk_a $clk_b is clock group"
        break
      }
    }

	    if {$clk_b == $clk_a} {
	        #set cmd [concat $cmd set_false_path -from [get_clock $clk_a] -to [get_clock $clk_b] \;]
	        set_false_path -from [get_clock $clk_a] -to [get_clock $clk_b]
	        echo "CMD0: set_false_path -from $clk_a -to $clk_b"
      } elseif {$is_same_group} {
	        #set cmd [concat $cmd set_false_path -from [get_clock $clk_a] -to [get_clock $clk_b] \;]
	        set_false_path -from [get_clock $clk_a] -to [get_clock $clk_b] 
	        echo "CMD1: set_false_path -from $clk_a -to $clk_b"
	    } else {
                set period_b [get_attribute [get_clock $clk_b] period]
	        if {$period_a < $period_b} {
	    	set min_period $period_a
	        } else {
	    	set min_period $period_b
	        }

	        #set cmd [concat $cmd set_max_delay [expr $async_coef*$min_period*0.7] -from [get_clock $clk_a] -to [get_clock $clk_b] -ignore_clock_latency \;]
	        set_max_delay [expr $async_coef*$min_period*0.7] -from [get_clock $clk_a] -to [get_clock $clk_b] -ignore_clock_latency 
	        echo "CMD: set_max_delay [expr $async_coef*$min_period*0.7] -from $clk_a -to $clk_b"
	    }
     set is_same_group 0
    }
}

### set max delay to gray paths
#foreach gray_key $gray_keys {
#    echo "#### $gray_key"
#    set gray_regs [lsort -dictionary [get_object_name [filter_collection [all_registers] -regexp "full_name=~.*$gray_key.*"]]]
#    foreach gray_reg $gray_regs {
#        set gray_d [get_object_name [get_pins -of_object [get_cells $gray_reg] -filter "is_async_pin == false && is_data_pin == true"]]
#        set gray_c [get_object_name [get_pins -of_object [get_cells $gray_reg] -filter "is_clock_pin == true"]]
#        set gray_p [lindex [lsort [get_attribute [get_attribute [get_pins $gray_c] clocks] period]] 0]
#	set st [get_object_name [all_fanin -to [get_pins $gray_d] -flat -startpoints_only]]
#	if {[llength $st] != 1 || ![regexp {^SDF} [get_attribute [get_cells $gray_reg] ref_name]]} {
#	    echo "Error: $gray_reg"
#	} elseif {[regexp $gray_key $st]} {
#	    echo "# $gray_reg"
#	} else {
#	    set st_p [lindex [lsort [get_attribute [get_attribute [get_pins $st] clocks] period]] 0]
#	    echo "$gray_reg"
#	    echo "CMD: set_max_delay [expr $gray_coef*$st_p] -from \[get_pins $st\] -to \[get_pins $gray_d\]"
#	    set cmd [concat $cmd set_max_delay [expr $gray_coef*$st_p] -from \[get_pins $st\] -to \[get_pins $gray_d\] -ignore_clock_latency \;]
#	}
#    }
#}
	    
#remove_clock_groups -all -asynchronous

eval $cmd


# efuse
set_max_delay 37.5 -from [get_pins $low_speed_hier/efuse_wrap_u/efuse_4kb_u*/STROBE] -to [get_pins $low_speed_hier/efuse_wrap_u/efuse_4kb_u*/Q*] -ignore_clock_latency

set_max_delay 2 -to   [get_pins "$low_speed_hier/efuse_wrap_u/efuse_4kb_u*/*"] -ignore_clock_latency
set_min_delay 0 -to   [get_pins "$low_speed_hier/efuse_wrap_u/efuse_4kb_u*/*"] -ignore_clock_latency

set_max_delay 5 -from [get_cells $low_speed_hier/efuse_wrap_u/efuse_ctrl_inst/efuse_A_reg*]  -to [get_cells $low_speed_hier/efuse_wrap_u/efuse_reg_inst/sig_sync_efuse_rdata_u/in_d_reg*] -ignore_clock_latency


# scp_reg
#set_max_delay 4 -from [get_pins "$scp_top_hier/scp_reg_top_inst/scp_reg_inst/inter_pads_*/Q"]  -to [get_pins $low_speed_hier/apb_ec_wrapper_u/iic_slave_inst/sig_sync_s*_in_inst/in_d_reg_0_/D] -ignore_clock_latency
set_false_path -from [get_pins "$scp_top_hier/scp_reg_top_inst/scp_reg_inst/inter_*/CK"]
set_false_path -to [get_pins "$scp_top_hier/scp_reg_top_inst/scp_reg_inst/sync_reg_*_inst/in_d_reg_*_/D*"]
set_false_path -from [get_pins "$scp_top_hier/scp_wdt_inst/DW_apb_wdt_inst*/U_DW_apb_wdt_regfile/wdt_torr_hold_reg*/CK"]
set_max_delay 2 -from [get_pins "$scp_top_hier/watchdog_gen_inst/timer*_int_dly_reg_*/CK"] -ignore_clock_laten



# reset
set_max_delay 6 -from [get_pins "$scp_top_hier/reset_ctrl_inst/rstn_mbist_pm_all_reg/Q"] -ignore_clock_latency
set_max_delay 4 -from [get_pins "$scp_top_hier/reset_ctrl_inst/reset_sync_inst_por_rst_sync_inst/syncrstz_clk_reg_*_/CK"] -ignore_clock_latency
set_max_delay 4 -from [get_pins "$scp_top_hier/reset_ctrl_inst/reset_sync_inst_por_rst_sync_inst/latchff_clk_reg/CK"] -ignore_clock_latency
set_max_delay 3 -from [get_pins "$scp_top_hier/scp_reg_top_inst/scp_reg_inst/cross_sync_trig_pre*/Y_reg_0_/CK" ]  -ignore_clock_latency
set_max_delay 2 -from [get_pins "$scp_top_hier/reset_ctrl_inst/lsp_ec_rstn_reg_*/CK"]  -ignore_clock_latency
set_max_delay 6 -from [get_pins "$scp_top_hier/watchdog_gen_inst/timer*_int_dly_reg_*/CK"] -ignore_clock_latency



#write_sdc $veri_dir/${design_name}_${TLIB_NAME}_cdc_${SVN_COPY}.sdc
