###############################################################################
# SAMSUNG8LPP
###############################################################################
if { $USE_HD_0P75 == 1 } {

set LIB_PATH  [list \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/22hd/hdl/lvt/3.00a/liberty/ccs  \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/22hd/hdl/rvt/3.00a/liberty/ccs  \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/20hd/hdl/lvt/3.00a/liberty/ccs  \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/20hd/hdl/rvt/3.00a/liberty/ccs  \
              ../scr/libtodb_scr \
              ]
set_app_var target_library  [list \
    sa08nlgllogl22hdl068f_sspg0p675vn40c.db_ccs_tn \
    sa08nlgslogl22hdl068f_sspg0p675vn40c.db_ccs_tn \
    sa08nlgllogl20hdl068f_sspg0p675vn40c.db_ccs_tn \
    sa08nlgslogl20hdl068f_sspg0p675vn40c.db_ccs_tn \
 ]

} elseif { $USE_HS_0P75 == 1 } {
  set LIB_PATH  [list \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/22hs/hsl/lvt/3.00a/liberty/ccs  \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/22hs/hsl/rvt/3.00a/liberty/ccs  \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/20hs/hsl/lvt/3.00a/liberty/ccs  \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/20hs/hsl/rvt/3.00a/liberty/ccs  \
              ../scr/libtodb_scr \
              ]
set_app_var target_library  [list \
    sa08nlgllogl22hsl068f_sspg0p675vn40c.db_ccs_tn \
    sa08nlgslogl22hsl068f_sspg0p675vn40c.db_ccs_tn \
    sa08nlgllogl20hsl068f_sspg0p675vn40c.db_ccs_tn \
    sa08nlgslogl20hsl068f_sspg0p675vn40c.db_ccs_tn \
 ]



} elseif {$USE_HS_0P85 == 1 } {
set LIB_PATH  [list \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/22hs/hsl/lvt/3.00a/liberty/ccs  \
              /Foundry/ARM/samsung_8lpp/Standard_Cell/SynopsysIP/samsung08nlvg/22hs/hsl/rvt/3.00a/liberty/ccs  \
              ../scr/libtodb_scr \
              ]

set_app_var target_library  [list \
sa08nlgslogl22hsl068f_sspg0p765vn40c.db_ccs_tn \
sa08nlgllogl22hsl068f_sspg0p765vn40c.db_ccs_tn \
 ]

} else {
echo  "-------------------------------------
Synthesis options that you should choose one!!!
But all of them are zero as show:
  USE_HS_0P75:        $USE_HS_0P75
  USE_HS_0P85:        $USE_HS_0P85
  USE_HD_0P75:        $USE_HD_0P75
-------------------------------------"
exit 
  }

set_app_var search_path         [concat $search_path $LIB_PATH]
set_app_var synthetic_library   [list dw_foundation.sldb standard.sldb]

#--------- Logic library
set LIB_EXT             "db"

# define MEMORY DEFINE for the libaray
#set MEM_DEF_LIST        CNM_TSMC28HPC
if {![info exist USE_PWR_RPT]}      { set USE_PWR_RPT   0 } 
if {![info exist USE_MIXED_LIB]}    { set USE_MIXED_LIB 0 } 
if {![info exist USE_LIB_M40]}      { set USE_LIB_M40   1 } 




set_app_var link_library "* $target_library $synthetic_library"
