#================================================
#		Basic Design Rule
# Note: please change based on the lib
#------------------------------------------------
set_max_fanout 16       [get_designs "*"]
set_max_transition 0.17  [get_designs "*"]


#================================================
#		Area 
#------------------------------------------------
set_max_area 0

#================================================
#		Design Constraint for Synthesis
#------------------------------------------------
# do not make 'assign' for output port is connected to a constant
set_fix_multiple_port_nets -all -buffer_constants

#  to split constant zeros, ones
#  constant net has ideal_net attribute so it is free from max_fanout, max_cap, max_transition
#  does not show error when "report_constraint -all"
set_auto_disable_drc_nets -constant false

#set_svf "$svf_dir/$design_name.svf"

#================================================
#       OCV adjustment
#------------------------------------------------
if { $USE_DERATING_FACTOR == 1 } {
    set_timing_derate -data -late -net_delay   $NET_DERATING_LATE_FACTOR
    set_timing_derate -data -late -cell_delay  $CELL_DERATING_LATE_FACTOR
    #set_timing_derate -data -net_delay  -late  $NET_DERATING_MAX
    #set_timing_derate -data -net_delay  -early $NET_DERATING_MIN
    #set_timing_derate -data -net_delay  -late  $NET_DERATING_MAX
    #set_timing_derate -data -net_delay  -early $NET_DERATING_MIN
}


#================================================
#       SET CRITICAL RANGE
#------------------------------------------------
set_critical_range 0.5 $design_name
