###############################################################################
# SAMSUNG8LPP
###############################################################################
#todo
set LIB_PATH  [list \
              /Foundry/ARM/samsung_5lpeAT/Standard_IO/samsung/ln05lpe_gpio_lib_1p8v_auto_V2.16_pkg/FE-Common_sec240516_0012/LIBERTY/NLDM \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l10 \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_lvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0094/LIBERTY/ln05lpe_sc_m7p5t_flk_lvt_c60l08 \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_rvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0093/LIBERTY/ln05lpe_sc_m7p5t_flk_rvt_c60l08 \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_flk_rvt_c60_a00_V3.01_pkg/FE-Common_sec240318_0093/LIBERTY/ln05lpe_sc_m7p5t_flk_rvt_c60l10 \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_mbslk_lvt_c60_a00_V1.20_pkg/FE-Common_sec240228_0197/LIBERTY/ln05lpe_sc_m7p5t_mbslk_lvt_c60l10 \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_mbslk_lvt_c60_a00_V1.20_pkg/FE-Common_sec240228_0197/LIBERTY/ln05lpe_sc_m7p5t_mbslk_lvt_c60l08 \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_mbslk_rvt_c60_a00_V1.20_pkg/FE-Common_sec240228_0196/LIBERTY/ln05lpe_sc_m7p5t_mbslk_rvt_c60l10 \
              /Foundry/ARM/samsung_5lpeAT/Standard_Cell/samsung/ln05lpe_sc_m7p5t_mbslk_rvt_c60_a00_V1.20_pkg/FE-Common_sec240228_0196/LIBERTY/ln05lpe_sc_m7p5t_mbslk_rvt_c60l08 \
              $GP3_RTL/tvsensor/syn_lib \
              ]


set_app_var search_path         [concat $search_path $LIB_PATH]
set_app_var synthetic_library   [list dw_foundation.sldb standard.sldb]

#--------- Logic library
set LIB_EXT             "db"

# define MEMORY DEFINE for the libaray
#set MEM_DEF_LIST        CNM_TSMC28HPC
if {![info exist USE_PWR_RPT]}      { set USE_PWR_RPT   0 } 
if {![info exist USE_MIXED_LIB]}    { set USE_MIXED_LIB 0 } 
if {![info exist USE_LIB_M40]}      { set USE_LIB_M40   1 } 


#todo
set_app_var target_library  [list \
ln05lpe_sc_m7p5t_flk_lvt_c60l10_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln05lpe_sc_m7p5t_flk_lvt_c60l08_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln05lpe_sc_m7p5t_flk_rvt_c60l08_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln05lpe_sc_m7p5t_flk_rvt_c60l10_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln05lpe_sc_m7p5t_mbslk_lvt_c60l10_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln05lpe_sc_m7p5t_mbslk_lvt_c60l08_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln05lpe_sc_m7p5t_mbslk_rvt_c60l10_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln05lpe_sc_m7p5t_mbslk_rvt_c60l08_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
inno_tsensor_ip_ss_cmax_m40_func.db \
]

set_app_var link_library "* $target_library $synthetic_library"
