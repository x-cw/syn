#================================================================================
# make verilog file list from simulation base
#
# author: Ethan Kim
# example)
#   set root_fn    "../../../sim/listfile/wave510_msvc.f"
#   set vflist [test_list $root_fn]
#   foreach fn $vflist {
#       puts "analyze -define ASIC_MEM_WAVE5 -f verilog $fn"
#   }
#================================================================================
proc parse_sim_list {filename} {
    set flist ""
    set f [open $filename]
    puts "--Start making verilog file list for synthesis from $filename --"
    while {[gets $f line] > -1} {
        # Process lines
        if {[regexp {^\s*\-f +(\S+)} $line -> qqq]} {
            set incpath [sh echo $qqq]
            puts "\[Parse\] $line: \"$incpath\" \n"
            if { [file exists $incpath] == 1} {
                set flist [concat $flist [parse_sim_list $incpath]]
            } else {
                puts "ERR> file not found: $incpath\n"
            }
        } elseif {[regexp {^\s*\+} $line]} {
            #puts "\[SKIP\] $line : skip (directive)\n"
        } elseif {[regexp {^\s*\#} $line]} {
            #puts "\[SKIP\] $line : skip (CPP directive)\n"
        } elseif {[regexp {^\/\/} $line]} {
            #puts "\[SKIP\] $line : skip comment\n"
        } elseif {[regexp {^\s*\.} $line]} {
            #puts "\[Add\]   $line"
            set flist [concat $flist $line]
        } else  {
        }
    }
    close $f
    puts "--- generation done: $filename ---"
    return $flist
}

define_proc_attributes parse_sim_list    -info "make verilog file list from that for simulation" \
-define_args { {root_file_names "top level list file" root_file_names list required} }

#================================================================================
# Profile Area - report the area and portion of design 
#
# author: TO, from Solvnet
# Modifier: Ethan Kim 
# Modification: exclude SNPS_CLOCK_GATE_ cells in the report
# Modification: add gate count calculation, change for 2017.06 version
# examples) 
#    profile_area  -level 4
#================================================================================
proc profile_area { args } {
  set space ""
  # default parameters
  set results(-level) 4
  set results(-gc) 0.378

  set tmpfile .profile_report123
  sh rm -f $tmpfile
  set hierfile .profile_hier123
  sh rm -f $hierfile

  parse_proc_arguments -args $args results
  set level $results(-level)
  set gc    $results(-gc)

  set version "1.5"
  echo "Running Profile Tool version $version (unit gate size = $gc)"
  echo "--------------------------------------------------------"

  set wildcard "*"
  set back ".."

  redirect $tmpfile {echo "level_is 0"}
  redirect $tmpfile -append {report_reference -nosplit}
  redirect $hierfile {report_hierarchy -nosplit}

  for { set lev 1 } { $lev < $level } { incr lev } {
       redirect /dev/null {set hier_cells [get_cells $wildcard -filter "@is_hierarchical==true"]}
       foreach_in_collection hc $hier_cells {
           set hc_name [get_object_name $hc]
           redirect /dev/null {current_instance $hc_name}
           redirect $tmpfile -append {echo "level_is $lev"}
           redirect $tmpfile -append {report_reference -nosplit}
           redirect /dev/null {current_instance $back}
       }
       set wildcard "${wildcard}/*"
       set back "${back}/.."
  }
  set outstring ""
  set levelnum 0

  if {[file exists $tmpfile]} {
    set tmp_reports [open $tmpfile r]
    while {[gets $tmp_reports line] >= 0} {
      if {[regexp {Design : (.*)} $line full parent]} {
        if {[regexp {([^ ]+) \(([^ ]+)\)} $parent toss inst parent]} { }
        set prims_tot($parent) 0
      } elseif {[regexp {Total [0-9]+ references[ ]+([0-9\.]+)} $line full total]} {
        set area($parent)     [expr {$total}]
        set numlv($parent)    [expr {$levelnum}]
      } elseif {[regexp {^([^ ]+)[ ]+([0-9\.]+)[ ]*([0-9]+)[ ]*([0-9\.]+)[ ]*([a-z, ]+)} \
                 $line full ref unit num total attr]} {
        if {[regexp {h|h,} $attr match]}  {
          set area($ref)    [expr {$total}]
          set numlv($ref)   [expr {$levelnum + 1}]
        } else {
          set prims_tot($parent) [expr {$prims_tot($parent) + $total}]
        }
      } elseif {[regexp {level_is ([0-9]+)} $line full levelnum]} {
      }
    }
  }

  set tot_area 0
  set memarr(0) 0
  set memarr(1) 0
  set memarr(2) 0
  set memarr(3) 0
  set memarr(4) 0
  set memarr(5) 0
  set memarr(6) 0
  set mem_name(1) "MEM SPREG"
  set mem_name(2) "MEM DPREG" 
  set mem_name(3) "MEM SPSRAM"
  set mem_name(4) "MEM TOTAL" 
  set mem_name(5) "LOGIC TOTAL"
  set mem_name(6) "TOTAL"

  if {[file exists $hierfile]} {
    set hier_reports [open $hierfile r]
    while {[gets $hier_reports line] >= 0} {
        if {[regexp {^\*\*\*\*} $line tmp]} {
        } elseif {[regexp {SNPS_CLOCK_GATE_} $line tmp]} {
        } elseif {[regexp {([ ]*)([^ ]+)} $line full space ref]} {
            if {[array names area $ref]!=""} {
               if { $tot_area == 0 } {
                   set tot_area $area($ref)
                   echo [format \
                       "%[string length $space]s%-50s%[expr {35-[string length $space]}]s | %12s |  %12s | %7s | %4s | %4s " \
                       $space "Reference" " " "Area" "GC($gc)" "Percent" "Dep" "Mem"]
               }
               set perc [expr {(1 - ($tot_area - $area($ref))/$tot_area)*100}]
               set cgc  [expr {($area($ref))/$gc }]

               # find out memory instance 
               if { [string match "*spreg*" $ref] } {
                  set memarr(1) [expr {$memarr(1) + $area($ref)}]
               } elseif { [string match "*dpreg*" $ref] } {
                  set memarr(2) [expr {$memarr(2) + $area($ref)}]
               } elseif { [string match "*spsram*" $ref] } {
                  set memarr(3) [expr {$memarr(3) + $area($ref)}]
               }
               set memfound [expr {[string match "*dpreg*" $ref] || [string match "*spreg*" $ref] || [string match "*spsram*" $ref] }]
               if { $memfound } {
                  set memarr(4) [expr {$memarr(4) + $area($ref)}]
               } 
               echo [format \
                       "%[string length $space]s%-50s%[expr {35-[string length $space]}]s | %12.1f |  %12.1f | %6.1f%% | %3d | %3d" \
                      $space $ref " " $area($ref) $cgc $perc $numlv($ref) $memfound]
            }
        }
    }
    set memarr(5) [expr {$tot_area - $memarr(4)}]
    set memarr(6) $tot_area 
    echo "-------------------------------------------------------------"
    for { set n 1 } { $n < 7 } { incr n } {
      set perc [expr {(1 - ($tot_area - $memarr($n))/$tot_area)*100}]
      set cgc  [expr {$memarr($n)/$gc}]  
      echo [format "%[string length $space]s%-50s%[expr {35-[string length $space]}]s | %12.1f |  %12.1f | %6.1f%%" \
           $space $mem_name($n) " " $memarr($n) $cgc $perc]
    }
  }

  close $hier_reports
  close $tmp_reports
}


define_proc_attributes profile_area -info "Show area across levels of hierarchy" \
  -define_args { 
    {-level "Level to profile - default 4"   Level   int     optional }
    {-gc    "Size of NAND2D2 - default 0.378"    GC      float   optional }
  }


#================================================================================
# exit when error code is asserted
#
# author: Ethan Kim
#================================================================================
proc snps_exit_on_error {} {
  if { [check_error -verbose ] == 1}  {
      echo "FATAL: Exit synthesis due to ERROR"
      #exit
  }
}

define_proc_attributes snps_exit_on_error -info "Exit when check_error is failed"

#================================================================================
# mark memory lib as HVt
#
# author: Ethan Kim
#================================================================================
# set MEMLIB to HVT
# TODO: change HVt or SVt or LVt if memory model uses that corner
proc mark_memlib_hvt { } {
    echo "Marking MEMLIB as HVt"
    # memory list setup
    foreach MEMLIB_COMP $args {
        set_attribute $MEMLIB_COMP -type string default_threshold_voltage_group HVt
        echo "$MEMLIB_COMP is marked as HVt lib"
    }
}

define_proc_attributes mark_memlib_hvt \
    -info "mark threshold group to memory libraries for more accurate report"  


proc report_memory_bit_ss14 {} {
    # need change here if library changed
    set keyword_depth "Number of Words.*:"
    set keyword_word "Number of Bits.*:"
    set keyword_compiler "Compiler Name"
#    set keyword_r2f  "Two Port Register File"
#    set keyword_r1f  "Single Port Register File"
#    set keyword_r1a  "Single Port SRAM"
    set mem_lib_path "../scr/libtodb_scr/lib/"

    set total_r1f_area 0
    set total_r2f_area 0
    set total_r1a_area 0
    set total_r1f_bits 0
    set total_r2f_bits 0
    set total_r1a_bits 0
    #get all memories
    set rams [get_cell -hier * -filter "is_memory_cell == true"]

    foreach_in_collection ram $rams {
        set type_r1f ""
        set type_r2f ""
        set type_r1a ""
        set ref_name [get_attribute $ram ref_name]
        set area [get_attribute -quiet $ram area]
        #get Word / Bits from library header, may need change to other format
        regexp {:\s*(\d+)} [sh grep -e "$keyword_depth" ${mem_lib_path}${ref_name}*.lib*]  matched mem_dep
        regexp {:\s*(\d+)}  [sh grep -e "$keyword_word" ${mem_lib_path}${ref_name}*.lib*]  matched mem_wid
        #get memory type from library header, may need change to other format
        set mem_type_line [sh grep -e "${keyword_compiler}" ${mem_lib_path}${ref_name}*.lib*]
        regexp {(Single Port Register File)} $mem_type_line  matched type_r1f
        regexp {(Two Port Register File)}    $mem_type_line  matched type_r2f
        regexp {(Single Port SRAM)}          $mem_type_line  matched type_r1a
        
        # Generate some summaries
        if {$type_r1f != ""} {
            set no_of_bits [expr $mem_dep*$mem_wid] 
            set total_r1f_area [expr ($total_r1f_area + $area)]
            set total_r1f_bits [expr ($total_r1f_bits + $no_of_bits)]
        } elseif {$type_r2f != ""} {
            set no_of_bits [expr $mem_dep*$mem_wid] 
            set total_r2f_area [expr ($total_r2f_area + $area)]
            set total_r2f_bits [expr ($total_r2f_bits + $no_of_bits)]
        } elseif {$type_r1a != ""} {
            set no_of_bits [expr $mem_dep*$mem_wid] 
            set total_r1a_area [expr ($total_r1a_area + $area)]
            set total_r1a_bits [expr ($total_r1a_bits + $no_of_bits)]
        }


    }
    # Print out the totals
    set outline "Total single port Register File number of bits: $total_r1f_bits"
    echo $outline
    set outline "Total dual   port Register File number of bits: $total_r2f_bits"
    echo $outline
    set outline "Total single port Sram          number of bits: $total_r1a_bits"
    echo $outline

    set outline "Total single port Register FIle area : $total_r1f_area"
    echo $outline
    set outline "Total dual   port Register File area : $total_r2f_area"
    echo $outline
    set outline "Total single port Sram          area : $total_r1a_area"
    echo $outline

}
