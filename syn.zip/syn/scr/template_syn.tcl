#================================================
#       WAVE5 SYNTHESIS SCRIPT
#================================================
sh date '+DATE: %m/%d/%y%nTIME: %H:%M'
set DC_VER  [string range $compatibility_version 2 8]

# set module name lenth limit to 256
set_app_var hdlin_module_name_limit 256
set_app_var hdlin_shorten_long_module_name "true"

#set G1_RTL  /home/Storage_Plugin/fengh/SVN_G1_PRJ_202003/frontend/src

#================================================
# script setup - default: HVT(target)
#---
# Default Parameterss
if {![info exist USE_PWR_RPT]}       {set USE_PWR_RPT       0 }
if {![info exist USE_MIXED_LIB]}     {set USE_MIXED_LIB     0 }
if {![info exist USE_LIB_M40]}       {set USE_LIB_M40       0 }
if {![info exist TLIB_NAME]}         {set TLIB_NAME         "samsung14lpu" }
# hplp: high performance, low power,  rtm_exp: better runtime  
if {![info exist OPTIMIZATION_FLOW]} {set OPTIMIZATION_FLOW "hplp" }; 
if {![info exist LOOP_COMP_CNT]}     {set LOOP_COMP_CNT     0}; #no loop compile
if {![info exist USE_SCAN]}          {set USE_SCAN          1}; #no SCAN compile
if {![info exist USE_NO_COMPILE]}    {set USE_NO_COMPILE    0}; #no compile for auto release test
if {![info exist USE_HS_0P75]}       {set USE_HS_0P75 0}; #no compile for auto release test
if {![info exist USE_HS_0P85]}       {set USE_HS_0P85 0}; #no compile for auto release test
if {![info exist USE_HD_0P75]}       {set USE_HD_0P75 0}; #no compile for auto release test

set CHECK_DP            0; # 1: Get Datapath reporting 
set REPORT_VERBOSE      0; # 1: print more verbose reporting
# MIXING OPTION: HVT and SVT 
set USE_LVT_IN_MIXLIB   0
set USE_SVT_IN_MIXLIB   1
set USE_HVT_IN_MIXLIB   1

# basic clock setting 

# Setting Design Name
set design_name     ${TOP_MODULE} 

set_svf "$svf_dir/$design_name.svf"

# check license for scan option
if { $USE_SCAN == 1 } {
    if {![check_license {Test-Compiler}]} {
        echo "Warning: Test-Compiler is not available."
        echo "         Synthesis w/o scan option"
        set USE_SCAN 0
    } 
}

echo  "-------------------------------------
Synthesis options that you use
  USE_PWR_RPT:        $USE_PWR_RPT
  USE_MIXED_LIB:      $USE_MIXED_LIB
  USE_LIB_M40:        $USE_LIB_M40
  TLIB_NAME:          $TLIB_NAME
  OPTIMIZATION_FLOW:  $OPTIMIZATION_FLOW
  LOOP_COMP_CNT:      $LOOP_COMP_CNT
  USE_SCAN:           $USE_SCAN
  USE_HS_0P75:        $USE_HS_0P75
  USE_HS_0P85:        $USE_HS_0P85
  USE_HD_0P75:        $USE_HD_0P75
-------------------------------------"

# set basename for reporting 
set RPT_NAME "${rpt_dir}/${design_name}_${TLIB_NAME}"


# add below 2 settings to ensure high fanout reset pin do not cause large delay,
# large fanout net only happens on ideal network since it is limited by set_max_fanout setting, so this setting will not affect nomal nets's timing analysis.
set_app_var high_fanout_net_threshold       80
set_app_var high_fanout_net_pin_capacitance 0.01


#-------------------------------------------------------------------------


set_app_var hdlin_infer_multibit default_all
#--------------------------------------
# Loading Process Depednet parameter 
# change this based on the library
if { $TLIB_NAME ==  "TSMC28HPC" } {
    source -e -v $scr_dir/process_tsmc28hpc.tcl
    set GATESIZE            0.378
} elseif { $TLIB_NAME == "TSMC28HPCPLUS"} {
    source -e -v $scr_dir/process_tsmc28hpcplus.tcl
    set GATESIZE            0.378
} elseif { $TLIB_NAME == "tsmc12ffc"} {
    source -e -v $scr_dir/process_tsmc12ffc.tcl
    set GATESIZE            0.378
} elseif { $TLIB_NAME == "samsung14lpp"} {
    source -e -v $scr_dir/process_samsung14lpp.tcl
    set GATESIZE            0.378
} elseif { $TLIB_NAME == "samsung5lpp"} {
    source -e -v $scr_dir/process_samsung5lpp.tcl
    set GATESIZE            0.378
} elseif { $TLIB_NAME == "samsung4lpp"} {
    source -e -v $scr_dir/process_samsung4lpp.tcl
    set GATESIZE            0.378
} elseif { $TLIB_NAME == "samsung14lpu"} {
    source -e -v $scr_dir/process_samsung14lpu.tcl
    set GATESIZE            0.378
} else {
    # target is not defined. Error 
    echo "target library is not defined"
    exit
}
# add library for mixed - default: LVT(target)
if { $USE_MIXED_LIB == 1 }  {
    set target_library ""
    if { $USE_LVT_IN_MIXLIB == 1 } {
        lappend target_library  $LVT_LIB.$LIB_EXT
        lappend link_library    $LVT_LIB.$LIB_EXT
    }
    if { $USE_SVT_IN_MIXLIB == 1 } {
        lappend target_library  $SVT_LIB.$LIB_EXT
        lappend link_library    $SVT_LIB.$LIB_EXT
    }
    if { $USE_HVT_IN_MIXLIB == 1} {
        lappend target_library  $HVT_LIB.$LIB_EXT
        lappend link_library    $HVT_LIB.$LIB_EXT
    }
}
 
# marking memory define
lappend MEM_DEF_LIST    ASIC_MEM
lappend MEM_DEF_LIST    CNM_ASIC_MEM
lappend MEM_DEF_LIST    TSMC12_MEM

#================================================
#add supporting procedures
source -e -v $scr_dir/syn_proc.tcl

# Core - from 2016.12 upto 8 using 1 license
if {$DC_VER >= 2016.12}  {
    echo "use 16 core"
    set_host_options -max_cores 16
} else {
    echo "use 4 core"
    set_host_options -max_cores 4
}
report_host_options

if { $USE_PWR_RPT ==1 } {
    # start mapping saif to RTL (should be call before analyze)
    saif_map -start
    # mark memory lib 
    mark_memlib_hvt
}

#---------------------------------------------------------------------
# Set clock gating 
#---------------------------------------------------------------------
set_clock_gating_style  -max_fanout 64 \
                        -sequential_cell latch \
                        -positive_edge_logic {integrated} \
                        -negative_edge_logic {integrated} \
                        -minimum_bitwidth 1 \
                        -control_point before

## some additional 
#set_app_var power_cg_all_registers true
#set_app_var power_remove_redundant_clock_gates true

#set_app_var enable_recovery_removal_arcs true

## for UICG cells
#set_app_var power_cg_auto_identify true
## TODO: handle ideal network for UICG 


#-----------------------------------------------------------------------
#       ANALYZE & ELABORATE SUB-BLOCK
# run HDL compiler using simulation list
#-----------------------------------------------------------------------
# set "top level" simulation listfile for synthesis 
#set root_fn ../../../sim/listfile/${design_name}.f

#set root_fn ../../../frontend/src/vcodec/file_list/wave521c_msvc_top.f
#set vflist ""
#set vflist [parse_sim_list $root_fn]
puts "\n-----------------------------------------\n"
#foreach fn $vflist {
#    analyze -define $MEM_DEF_LIST -f verilog $fn
#}
if {[info exist TOP_SV_FILELIST]} {
analyze -f sverilog -vcs "-f ${TOP_SV_FILELIST}"
}
if {[info exist TOP_VHDL_FILELIST]} {
analyze -f VHDL     -vcs "-f ${TOP_VHDL_FILELIST}"
}
if {[info exist TOP_FILELIST]} {
    analyze -f verilog  -vcs "-f ${TOP_FILELIST}"
}

#read_verilog -netlist ../../../../syn_audio_wrap/veri/audio_pipeline_wrap_samsung5lpp.v
#return
elaborate $design_name
if { $TLIB_NAME == "samsung14lpp"} {
    set_wire_load_model -name Zero
} 
#todo


#TODO
#set_wire_load_model -name ZeroWireload
link
snps_exit_on_error

#set_case_analysis 0 [get_pins display_pipeline_top_u1/u_clkgen/pcp] 
#set_case_analysis 0 [get_pins display_pipeline_top_u2/u_clkgen/pcp] 
#set_case_analysis 0 [get_pins display_pipeline_top_u3/u_clkgen/pcp] 
#set_case_analysis 0 [get_pins display_pipeline_top_u4/u_clkgen/pcp] 
#set_case_analysis 1 [get_pins display_pipeline_top_u1/u_clkgen/lce_display_enb] 
#set_case_analysis 1 [get_pins display_pipeline_top_u2/u_clkgen/lce_display_enb] 
#set_case_analysis 1 [get_pins display_pipeline_top_u3/u_clkgen/lce_display_enb] 
#set_case_analysis 1 [get_pins display_pipeline_top_u4/u_clkgen/lce_display_enb] 
#set_case_analysis 1 [get_pins u_clkgen/lce_display_enb] 
#set_case_analysis 0 [get_ports scan_mode]
#set_case_analysis 0 [get_ports scan_clk]

#set_case_analysis 0 [get_ports i_test_mode]

# check datapath for reviewing 
if { $CHECK_DP == 1 } {
    analyze_datapath_extraction > $RPT_NAME.unmapped.dp
}
check_design        >   $RPT_NAME.unmapped.chk
#check_design -html      $RPT_NAME.unmapped.html

# write unmapped ddc for recurrent synthesis
write -hierarchy -format ddc -output "$db_dir/$design_name.unmapped.ddc"


#---------------------------------------------------------------------
# Constraints
#---------------------------------------------------------------------
## Start Constraints
#reset_design 
current_design  $design_name
link
#return
#source -e -v $scr_dir/clock_constraints.tcl
#source -e -v $scr_dir/delay_constraints.tcl
#source -e -v $scr_dir/default_condition.tcl

source -e -v ../sdc/scp_top_wrap.sdc
#return
#set_clock_uncertainty 0.450 [all_clocks]
set_clock_uncertainty 0.600 [get_clock "pll_scp_clk"]

#TODO


# s14lpp
#set dont_use_list "**TIE*  *X0* *TIE* *DLY* *CLK* *_X20* *_X24* *_X28* *_X32* *FRICG* *INVP* *_X*G* *DFFQA4W_X1N_* *A9PP84TSL*"
# s14lpu
#set dont_use_list     "**TIE*  *X0* *TIE* *DLY* *CLK* *_X20* *_X24* *_X28* *_X32* *FRICG* *INVP* *_X*G* DFFQA4W_X1N_* *A9PP84TSL* *H_X* *L_X* *X36* *X54* *X72* *X90* *X108* *126* *X144* *TSL*C14 *ECO* *_X16* *_X14*"
set dont_use_list "*TIE* *DLY* *ANTENNA* *ECO* SPARE* *FILL* MX2_* SDFFY*Q*D* *CLK* *BUFH* *INVH* *INVP* *_D0P7*  *_D20* *_D24* *_D28* *_D32* *S8P25TSL* *DFF*2BS_* *DFF*8BS_*  *LAT* *TSL*"


foreach dont_use_cell $dont_use_list {
  set_dont_use [get_lib_cells */$dont_use_cell ]
  }

#remove_attribute [get_lib_cells */*DFF*L2W*] dont_use


#**************************************************************
# Not allow constant to be optimized through boundary
#**************************************************************
#global
#set compile_enable_constant_propagation_with_no_boundary_opt false


#**************************************************************
# Set dont touch cell 
#**************************************************************
if { [sizeof_collection [get_cells -filter "full_name =~ *dont_touch_*" -hier]] !=0} {
set_dont_touch [get_cells -filter "full_name =~ *dont_touch_*" -hier] 
}

#Caution!! Change the dont touch clock gate location you want to set in your design
#if { [sizeof_collection [get_pins  -filter "full_name =~ *dont_touch_clk_gate_u/ECK" -hierarchical]] !=0} {
#   set_ideal_network [get_pins  -filter "full_name =~ *dont_touch_clk_gate_u/ECK" -hierarchical]
#}
# check error
#snps_exit_on_error

set_dont_touch [get_cells low_speed_misc_wrap_inst/jtag2axi_top_inst/tap_inst/latch_tdo_inst]

set_dont_touch_network [get_pins dft_top_inst.u_cell_clk_buf*_inst*/*]
#---------------------------------------------------------------------
#                 POWER INTEND
#---------------------------------------------------------------------
current_design  $design_name
if { $USE_MIXED_LIB == 1 } {
    # mark cell lib
    if { $USE_HVT_IN_MIXLIB == 1 } {
        set_attribute [get_libs $HVT_LIB] -type string default_threshold_voltage_group HVt
    }
    if { $USE_SVT_IN_MIXLIB == 1 } {
        set_attribute [get_libs $SVT_LIB] -type string default_threshold_voltage_group SVt
    }
    if { $USE_LVT_IN_MIXLIB == 1 } {
        set_attribute [get_libs $LVT_LIB] -type string default_threshold_voltage_group LVt
    }

    ## New method from 2011 (non multicorner nor multimode)
    set_leakage_optimization true 
    set_dynamic_optimization true

    ## DO NOT USE w/o specific reason
    #set_multi_vth_constraint -lvth_groups {lvt} -lvth_percentage 20 -type soft

    ## for faster - from 2013
    #set power_opto_simple_leakage_mode true
}

if { $USE_PWR_RPT ==1 } {
    # just for example
    read_saif -auto_map_names \
        -instance_name testbench/u_${design_name} \
        -input ../../../sim/vectors/codec/result/WAVE_000.saif -verbose
    report_saif -hier -rtl_saif -missing > $RPT_NAME.missing_saif

}

#---------------------------------------------------------------------
# Design Dependent Exceptions
#---------------------------------------------------------------------
#                 Multi-Cycle Path
#---------------------------------------------------------------------
#if { [file exists $scr_dir/mcp_$design_name.tcl] } {
#    source -e -v  $scr_dir/mcp_$design_name.tcl
#}

# Uniquify - No need
current_design  $design_name

set uniquify_naming_style "${design_name}_%s_%d"

uniquify -force
#---------------------------------------------------------------------
#                 UNGROUP
#---------------------------------------------------------------------
if { [file exists $scr_dir/ungroup_$design_name.tcl] } {
    source -e -v $scr_dir/ungroup_$design_name.tcl
}

# Ungroup for HLS
#set wait_ctrl_inst [find -hierarchy cell {*_triosy_obj_inst *_synci_inst *_staller_inst *_rsci*_inst}]
#if { [llength $wait_ctrl_inst ] > 0 } {
#    ungroup $wait_ctrl_inst -flatten
#}

#---------------------------------------------------------------------
#                 Check Loop 
#---------------------------------------------------------------------
# check timing loop before compile 
report_timing -loop > $RPT_NAME.loop
check_timing  > $RPT_NAME.unmapping.chk_timing
snps_exit_on_error

if { $USE_NO_COMPILE == 1 } {
    quit
}

# add for multibit function
set_multibit_options -mode timing_driven

#clock gating exception
set_clock_gating_enable -exclude [all_inputs]
#---------------------------------------------------------------------
#        ungroup lower hierarchy 
#---------------------------------------------------------------------

#set ungroup_cells                  [get_cells databus_top_wrap_u/databus_top_u/databus_matrix/* -filter "ref_name !~ *_C* && ref_name !~ *logic_*"]
#append_to_collection ungroup_cells [get_cells databus_top_wrap_u/databus_top_u/* -filter "ref_name !~ *_C* && ref_name !~ *logic_* && ref_name !~ *databus_matrix*"]
#append_to_collection ungroup_cells [get_cells cfgbus_top_wrap_u/cfgbus_top_u/cfgbus_matrix/* -filter "ref_name !~ *_C* && ref_name !~ *logic_*"]
#append_to_collection ungroup_cells [get_cells cfgbus_top_wrap_u/cfgbus_top_u/* -filter "ref_name !~ *_C* && ref_name !~ *logic_*  && ref_name !~ *cfgbus_matrix*"]
#sizeof_collection $ungroup_cells
set ungroup_cells ""
#set ungroup_cells "[get_cells scp_top_inst/scp_bus_inst//niu* -filter "ref_name !~ *_C* && ref_name !~ *logic_* && is_hierarchical == true"]"
#append_to_collection ungroup_cells [get_cells scp_top_inst/scp_bus_inst/matrix/* -filter "ref_name !~ *_C* && ref_name !~ *logic_* && is_hierarchical == true"]

if {$ungroup_cells != ""} {
    foreach_in_collection cells $ungroup_cells {
        set cell_name [get_attribute ${cells} full_name]
        if {[get_cells ${cell_name}/* -filter "is_hierarchical == true"] != ""} {
            ungroup -flatten [get_cells ${cell_name}/* -filter "is_hierarchical == true"]
#            echo "$cell_name"
        }
    }
}
# compile_ultra -no_autoungroup


#---------------------------------------------------------------------
#        to improve scan coverage 
#---------------------------------------------------------------------

set compile_seqmap_identify_shift_registers false

#---------------------------------------------------------------------
#        to do retime for  
#---------------------------------------------------------------------

#ref_name of mudule
#set retimed_modules "noc_bus_top_wrap_databus_top_NIU_module_mst0_pcie_0 noc_bus_top_wrap_databus_top_NIU_module_slv2_ddr2_0 noc_bus_top_wrap_databus_top_NIU_module_mst2_apu_0"

#target period when runing synthesis
set timing_retime_threshold 0.80 

#set disable clock_gate in these modules (1 to disable)
set disable_module_auto_clock_gate 1
if {[info exists retimed_modules]} {
   if {${retimed_modules} != ""} {
      foreach des $retimed_modules {
         echo "Info: Apply retiming attributes to design $des with delay threshold set to ${timing_retime_threshold}"
         set_optimize_registers -design $des true \
            -check_design -verbose -print_critical_loop -justification_effort high \
            -delay_threshold ${timing_retime_threshold}
          if {[info exists disable_module_auto_clock_gate]} {
              if {${disable_module_auto_clock_gate} == 1} {
                  echo "Info: diable auto_clock_gate in module [get_attribute [get_cells -filter "ref_name =~ $des" -hierarchical] full_name] "
                  set_clock_gating_objects -exclude [get_cells -filter "ref_name =~ $des" -hierarchical]
              }
          }
      }
   }
}

#---------------------------------------------------------------------
#                 COMPILE
#---------------------------------------------------------------------
# base option 
# compile_ultra -gate_clock -scan
set COMP_FLAG "-gate_clock"
#if { $USE_SCAN == 1 } {
    set COMP_FLAG [concat $COMP_FLAG "-scan"]
#}
set COMP_FLAG [concat $COMP_FLAG "-no_autoungroup"]
#
#if { $OPTIMIZATION_FLOW == "hplp" } {
#    set_app_var compile_register_replication_across_hierarchy true 
#    #---------------------------------------------------------------------
#    #                 RETIME
#    #---------------------------------------------------------------------
#    #if { [file exists $scr_dir/retime_$design_name.tcl] } { 
#    #    source -e -v $scr_dir/retime_$design_name.tcl
#    #    snps_exit_on_error
#    #}
#    set COMP_FLAG [concat $COMP_FLAG "-retime"]
#} 
#if { $OPTIMIZATION_FLOW == "rtm_exp" } {
#    compile_prefer_runtime
#}

sh date '+DATE: %m/%d/%y%nTIME: %H:%M'

#clock gating exception for memory input/output pins
#set pin_mem_in [get_pins -of [get_cells -hier -filter "is_macro_cell == true"] -filter "pin_direction =~ in*"]
set pin_mem_out [get_pins -of [get_cells -hier -filter "is_macro_cell == true"] -filter "pin_direction =~ out*"]
#set_clock_gating_enable -exclude $pin_mem_in
set_clock_gating_enable -exclude $pin_mem_out

#--------------------------------------------------------------------
# Set Group Path for Input / Output / Feedthrough 
#--------------------------------------------------------------------
#set ports_clock_root [get_ports [all_fanout -flat -clock_tree -level 0]]
set ports_clock_root [get_clocks]
group_path -name REG2OUT -from [all_registers] -to [all_outputs] -weight 1
group_path -name IN2REG  -from [remove_from_collection [all_inputs] $ports_clock_root] -to [all_registers] -weight 1
group_path -name IN2OUT  -from [remove_from_collection [all_inputs] $ports_clock_root] -to [all_outputs] -weight 1
group_path -name REG2REG -from [all_registers] -to [all_registers] -weight 3

group_path -name MEM2REG -from [get_cells * -hier -filter "is_macro_cell == true"] -to [all_registers]  -weight 5
#group_path -name mem2reg -from [get_pins -of [get_cells -hier -filter "is_macro_cell == true"] -filter "pin_direction =~ out*"] -to [all_registers]  -weight 5

group_path -name REG2NIU -from [all_registers] -to [filter [all_register] "full_name =~ scp_top_inst/scp_bus_inst/*"] -weight 5
group_path -name REG2TE -from [all_registers] -to [filter [all_register] "full_name =~ trust_engine_wrapper_inst/trust_engine_inst*"] -weight 5
group_path -name REG2SCR1 -from [all_registers] -to [filter [all_register] "full_name =~ scp_top_inst/scr1_top_axi_inst/i_core_top*"] -weight 5
group_path -name REG2TIM -from [all_registers] -to [filter [all_register] "full_name =~ scp_top_inst/DW_apb_timers_inst/U_apbif*"] -weight 5

set path_groups "IN2REG REG2OUT IN2OUT REG2REG MEM2REG REG2NIU REG2TE REG2SCR1 REG2TIM"


set verilogout_no_tri true
# multiple outputs and constants are buffered
set_fix_multiple_port_nets -all -buffer_constants

eval compile_ultra $COMP_FLAG


change_names -rules verilog -hier


if { $OPTIMIZATION_FLOW == "hplp" } {
    # Loop compile 
    for { set lc 0} {$lc < $LOOP_COMP_CNT } {incr lc} {
        # store result
        echo "Loop Compiling: $lc "
        update_timing 
        write -hierarchy -format ddc     -output "$db_dir/${design_name}_${TLIB_NAME}.comp_$lc.ddc"
        parallel_execute [ list \
            "check_design                > $RPT_NAME.comp_$lc.chk"  \
            "report_area                 > $RPT_NAME.comp_$lc.area" \
            "report_reference            > $RPT_NAME.comp_$lc.ref"  \
            "report_reference -hier      > $RPT_NAME.comp_$lc.ref_hier" \
            "report_timing -path full -delay max -net -max_paths 100 -nworst 10 > $RPT_NAME.comp_$lc.tim" ] 
        profile_area -level 3 -gc $GATESIZE > $RPT_NAME.comp_$lc.area_prof
        # recompile w/o retiming 
        eval compile_ultra -incr $COMP_FLAG
    }
}

echo  "-------------------------------------
Synthesis options that you use
  COMP_FLAG:          $COMP_FLAG
  -------------------------------------"



# make final report for the compiled design
update_timing 
parallel_execute [ list \
    "check_design                > $RPT_NAME.chk"  \
    "report_area                 > $RPT_NAME.area" \
    "report_reference            > $RPT_NAME.ref"  \
    "report_reference -hier      > $RPT_NAME.ref_hier" \
    "report_timing -path full -delay max -net -max_paths 100 -nworst 10 > $RPT_NAME.$design_name.tim" ] 
profile_area -level 3 -gc $GATESIZE  > $RPT_NAME.area_prof

if { $REPORT_VERBOSE == 1 } {
    # full timing report w/ cap
    report_timing -path full -delay max -net -capacitance -nosplit > $RPT_NAME.a$CLK_BUS_FREQ.c$CLK_CORE_FREQ.tim
    report_port -verbose > $RPT_NAME.port
}
#---------------------------------------------------------------------
# report setup for group path
#---------------------------------------------------------------------
foreach _path_group_setup $path_groups {
  report_timing \
  -delay_type max \
  -path_type full_clock \
  -nworst 1 \
  -max_paths 1000 \
  -slack_lesser_than 0.0 \
  -nosplit -input_pins -nets -transition_time -capacitance \
  -group ${_path_group_setup} \
  > $RPT_NAME.setup_tim.${_path_group_setup}
sh perl /Temp/yaoys/script/check_violation_summary.V3.pl $RPT_NAME.setup_tim.${_path_group_setup} > $RPT_NAME.rep.rpt.sum.${_path_group_setup}
sh perl /Temp/yaoys/script/sort_sta_violation_summary.pl $RPT_NAME.rep.rpt.sum.${_path_group_setup} > $RPT_NAME.rep.rpt.sort.${_path_group_setup}
sh rm -rf $RPT_NAME.rep.rpt.sum.${_path_group_setup}
}

#---------------------------------------------------------------------
# dont_touch_list
#---------------------------------------------------------------------

set dont_touch_list [get_cells -hierarchical *dont_touch*]
redirect $veri_dir/dont_touch.cell {
puts "[join [get_object_name $dont_touch_list] "\n"]"
}
#---------------------------------------------------------------------
# Aux. Check
#---------------------------------------------------------------------
parallel_execute [ list \
    "report_cell -nosplit [find cell -hierarchy *] > $RPT_NAME.cell"    \
    "report_timing_derate           > $RPT_NAME.time_derate"   \
    "report_clock_gating            > $RPT_NAME.cg"    \
    "report_clock_gating -gated     > $RPT_NAME.gated" \
    "report_clock_gating -ungated   > $RPT_NAME.ungated"   \
    "report_qor > $RPT_NAME.qor" ]


#---------------------------------------------------------------------
# error case
#---------------------------------------------------------------------
report_timing -loop > $RPT_NAME.loop
get_cells -hier -filter "@is_unmapped==true" > $RPT_NAME.unmapped
report_cell [get_cells -hier -filter "@is_black_box==true"] > $RPT_NAME.black_box



#---------------------------------------------------------------------
# Power
#---------------------------------------------------------------------
if { $USE_PWR_RPT   == 1 ||  $USE_MIXED_LIB == 1 } {
    #report_power -analysis_effort medium >  $rpt_dir/$design_name.pwr
    report_power -analysis_effort medium -hier -v  >  $RPT_NAME.pwr_verb
    if { $USE_MIXED_LIB == 1 } { 
        report_threshold_voltage_group -lvth_groups {LVt} -verbose > $RPT_NAME.pwr_grp
    }
}

#---------------------------------------------------------------------
# Memory bit
#---------------------------------------------------------------------
#report_memory_bit_ss8 > $RPT_NAME.mem_bits

#---------------------------------------------------------------------
#                  WRITE DB
#---------------------------------------------------------------------
write -hierarchy -format verilog -output "$veri_dir/${design_name}_${TLIB_NAME}.v"
write -hierarchy -format ddc     -output "$db_dir/${design_name}_${TLIB_NAME}.ddc"

# write out sdc for post
remove_path_group $path_groups
write_sdc $veri_dir/${design_name}_${TLIB_NAME}_forBE.sdc
check_timing  > $RPT_NAME.chk_timing

remove_sdc
if { $TLIB_NAME == "samsung14lpp"} {
    set_wire_load_model -name Zero
} 
#set_wire_load_model -name ZeroWireload


sh cat ../sdc/scp_top_wrap.sdc > ../sdc/scp_top_wrap_post.sdc
sh sed -i 's/inst\\./inst_/g'  ../sdc/scp_top_wrap_post.sdc
exec sed -i {s/\[\([0-9]*\)\]/_\1_/g} ../sdc/scp_top_wrap_post.sdc

source -e -v ../sdc/scp_top_wrap_post.sdc
write_sdc $veri_dir/${design_name}_${TLIB_NAME}_forBE.sdc



#source -e -v ../run/gen_no_timing_check_list
source -e -v ../run/gen_cdc_no_timing_check_list

#add cdc constraint
#source -e -v $scr_dir/clock_constraints_cdc.tcl
source -e -v $scr_dir/cdc.tcl

write_sdc $veri_dir/${design_name}_${TLIB_NAME}_cdc_forBE.sdc

set ports_clock_root [get_clocks]
group_path -name REG2OUT -from [all_registers] -to [all_outputs] -weight 1
group_path -name IN2REG  -from [remove_from_collection [all_inputs] $ports_clock_root] -to [all_registers] -weight 1
group_path -name IN2OUT  -from [remove_from_collection [all_inputs] $ports_clock_root] -to [all_outputs] -weight 1
group_path -name REG2REG -from [all_registers] -to [all_registers] -weight 3

set path_groups "IN2REG REG2OUT IN2OUT REG2REG"
foreach _path_group_setup $path_groups {
  report_timing \
  -delay_type max \
  -path_type full_clock \
  -nworst 1 \
  -max_paths 2000 \
  -slack_lesser_than 0.0 \
  -nosplit -input_pins -nets -transition_time -capacitance \
  -group ${_path_group_setup} \
  > $RPT_NAME.cdc.${_path_group_setup}
sh perl /Temp/yaoys/script/check_violation_summary.V3.pl $RPT_NAME.cdc.${_path_group_setup} > $RPT_NAME.cdc.sum.${_path_group_setup}
sh perl /Temp/yaoys/script/sort_sta_violation_summary.pl $RPT_NAME.cdc.sum.${_path_group_setup} > $RPT_NAME.cdc.sort.${_path_group_setup}
sh rm -rf $RPT_NAME.cdc.sum.${_path_group_setup}
}




source $scr_dir/gate_level_rpt.tcl
remove_sdc
source -e -v $veri_dir/${design_name}_${TLIB_NAME}_forBE.sdc
set_clock_uncertainty 0.600 [get_clock "pll_scp_clk"]

sh date '+DATE: %m/%d/%y%nTIME: %H:%M'

set_svf -off

sh sed -i '/set_ideal_network/d' $veri_dir/*.sdc
sh sed -i '/set_clock_uncertainty/d' $veri_dir/*.sdc

set cur_date [sh date +%y%m%d_%H]
sh cp ../svf/              ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}   -rf
sh cp ../veri/             ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}   -rf
sh cp ../rpt/              ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}   -rf
sh cp ../db/               ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}   -rf
sh cp ../run/${design_name}_syn.log   ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}
sh mv ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}/veri/${design_name}_${TLIB_NAME}_forBE.sdc ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}/veri/${design_name}_${TLIB_NAME}_forBE_${SYN_VERSION}_${BASE_LINE}.sdc
sh mv ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}/veri/${design_name}_${TLIB_NAME}_cdc_forBE.sdc ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}/veri/${design_name}_${TLIB_NAME}_cdc_forBE_${SYN_VERSION}_${BASE_LINE}.sdc
sh mv ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}/veri/${design_name}_${TLIB_NAME}.v ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}/veri/${design_name}_${TLIB_NAME}_${SYN_VERSION}_${BASE_LINE}.v
sh cp ../sdc/scp_top_wrap.sdc              ../${design_name}_netlist_${cur_date}_${SYN_VERSION}_${BASE_LINE}/veri/   -rf

echo "Synthesis is done, bellow is to generate no_timing_check_list for post simulation---"



#quit
