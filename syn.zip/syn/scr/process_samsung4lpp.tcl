###############################################################################
# SAMSUNG8LPP
###############################################################################
#todo
set LIB_PATH  [list \
              /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_rvt_c60_V1.11_pkg/FE-Liberty/FE-Liberty_sec250610_0171/LIBERTY/flk \
              /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_rvt_c60_V1.11_pkg/FE-Liberty/FE-Liberty_sec250610_0171/LIBERTY/flk \
              /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_lvt_c60_V1.11_pkg/FE-Liberty/FE-Liberty_sec250610_0170/LIBERTY/flk \
              /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_flk_lvt_c60_V1.11_pkg/FE-Liberty/FE-Liberty_sec250610_0170/LIBERTY/flk \
              /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_mbslk_rvt_c60_V1.08_pkg/FE-Liberty/FE-Liberty_sec250610_0113/LIBERTY/mbslk \
              /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_mbslk_rvt_c60_V1.08_pkg/FE-Liberty/FE-Liberty_sec250610_0113/LIBERTY/mbslk \
              /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_mbslk_lvt_c60_V1.08_pkg/FE-Liberty/FE-Liberty_sec250610_0111/LIBERTY/mbslk \
              /Foundry/ARM/samsung_4lpp/Standard_Cell/samsung/ln04lpp_sc_s7p94t_mbslk_lvt_c60_V1.08_pkg/FE-Liberty/FE-Liberty_sec250610_0111/LIBERTY/mbslk \
              ]

set_app_var search_path         [concat $search_path $LIB_PATH]
set_app_var synthetic_library   [list dw_foundation.sldb standard.sldb]

#--------- Logic library
set LIB_EXT             "db"

# define MEMORY DEFINE for the libaray
#set MEM_DEF_LIST        CNM_TSMC28HPC
if {![info exist USE_PWR_RPT]}      { set USE_PWR_RPT   0 } 
if {![info exist USE_MIXED_LIB]}    { set USE_MIXED_LIB 0 } 
if {![info exist USE_LIB_M40]}      { set USE_LIB_M40   1 } 



#todo
set_app_var target_library  [list \
ln04lpp_sc_s7p94t_flk_rvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln04lpp_sc_s7p94t_flk_rvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln04lpp_sc_s7p94t_flk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln04lpp_sc_s7p94t_flk_lvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln04lpp_sc_s7p94t_mbslk_rvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln04lpp_sc_s7p94t_mbslk_rvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln04lpp_sc_s7p94t_mbslk_lvt_c60l06_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
ln04lpp_sc_s7p94t_mbslk_lvt_c60l04_sspg_nominal_max_0p7650v_m40c.db_ccs_tn_lvf \
]

set_app_var link_library "* $target_library $synthetic_library"
