remove_sdc

source -e -v $veri_dir/${design_name}_${TLIB_NAME}_forBE.sdc

set_clock_uncertainty 1.0000 [all_clocks]

set ports_clock_root [get_clocks]
group_path -name REG2OUT -from [all_registers] -to [all_outputs] -weight 1
group_path -name IN2REG  -from [remove_from_collection [all_inputs] $ports_clock_root] -to [all_registers] -weight 1
group_path -name IN2OUT  -from [remove_from_collection [all_inputs] $ports_clock_root] -to [all_outputs] -weight 1
group_path -name REG2REG -from [all_registers] -to [all_registers] -weight 3




set path_groups "IN2REG REG2OUT IN2OUT REG2REG"
#foreach _path_group_setup $path_groups {
#  report_timing \
#  -delay_type max \
#  -path_type full_clock \
#  -nworst 1 \
#  -max_paths 10000 \
#  -slack_lesser_than 1.0 \
#  -nosplit -input_pins -nets -transition_time -capacitance \
#  -group ${_path_group_setup} \
#  > $RPT_NAME.setup_tim_gate_level.${_path_group_setup}
#  sh sed -i '/slack (MET)/s/.*/slack (VIOLATION) -0.02/' $RPT_NAME.setup_tim_gate_level.${_path_group_setup}
#sh perl /Temp/yaoys/script/check_violation_summary.V3.pl $RPT_NAME.setup_tim_gate_level.${_path_group_setup} > $RPT_NAME.rep.rpt.sum.gate_level.${_path_group_setup}
#}

foreach _path_group_setup $path_groups {
  report_timing \
  -delay_type max \
  -path_type full_clock \
  -nworst 1 \
  -max_paths 2000 \
  -slack_lesser_than 0.0 \
  -nosplit -input_pins -nets -transition_time -capacitance \
  -group ${_path_group_setup} \
  > $RPT_NAME.gl.${_path_group_setup}
sh perl /Temp/yaoys/script/check_violation_summary.V3.pl $RPT_NAME.gl.${_path_group_setup} > $RPT_NAME.gl.sum.${_path_group_setup}
sh perl /Temp/yaoys/script/sort_sta_violation_summary.pl $RPT_NAME.gl.sum.${_path_group_setup} > $RPT_NAME.gl.sort.${_path_group_setup}
sh rm -rf $RPT_NAME.gl.sum.${_path_group_setup}
}
