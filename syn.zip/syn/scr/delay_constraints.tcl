#-------------------------------------------------------------------------------
# Setup Input and Output Delay for WAVE510
#-------------------------------------------------------------------------------
# $Id: delay_wave5.tcl 145466 2018-04-24 11:18:07Z ethan.kim $
# $LastChangedBy: ethan.kim $
#-------------------------------------------------------------------------------
#set CLK_HOST_INPUT_DELAY    [expr {$CLK_HOST_PERIOD *(1-$SKEW_RATIO)* $INPUT_DELAY_GAIN}]
#set CLK_HOST_OUTPUT_DELAY   [expr {$CLK_HOST_PERIOD *(1-$SKEW_RATIO)* $OUTPUT_DELAY_GAIN}]
#set CLK_CORE_INPUT_DELAY    [expr {$CLK_CORE_PERIOD *(1-$SKEW_RATIO)* $INPUT_DELAY_GAIN}]
#set CLK_CORE_OUTPUT_DELAY   [expr {$CLK_CORE_PERIOD *(1-$SKEW_RATIO)* $OUTPUT_DELAY_GAIN}]
#set CLK_BPU_INPUT_DELAY     [expr {$CLK_BPU_PERIOD *(1-$SKEW_RATIO)* $INPUT_DELAY_GAIN}]
#set CLK_BPU_OUTPUT_DELAY    [expr {$CLK_BPU_PERIOD *(1-$SKEW_RATIO)* $OUTPUT_DELAY_GAIN}]
#set CLK_BUS_INPUT_DELAY     [expr {$CLK_BUS_PERIOD *(1-$SKEW_RATIO)* $INPUT_DELAY_GAIN}]
#set CLK_BUS_OUTPUT_DELAY    [expr {$CLK_BUS_PERIOD *(1-$SKEW_RATIO)* $OUTPUT_DELAY_GAIN}]
if {$CLK_HOST_PERIOD_ACTUAL > 10} {
  set CLK_HOST_INPUT_DELAY    [expr {$CLK_HOST_PERIOD_ACTUAL *1* $INPUT_DELAY_GAIN_LOW}]
  set CLK_HOST_OUTPUT_DELAY   [expr {$CLK_HOST_PERIOD_ACTUAL *1* $OUTPUT_DELAY_GAIN_LOW}]
} else {
  set CLK_HOST_INPUT_DELAY    [expr {$CLK_HOST_PERIOD_ACTUAL *1* $INPUT_DELAY_GAIN}]
  set CLK_HOST_OUTPUT_DELAY   [expr {$CLK_HOST_PERIOD_ACTUAL *1* $OUTPUT_DELAY_GAIN}]
}
if {$CLK_CORE_PERIOD_ACTUAL > 10} {
  set CLK_CORE_INPUT_DELAY    [expr {$CLK_CORE_PERIOD_ACTUAL *1* $INPUT_DELAY_GAIN_LOW}]
  set CLK_CORE_OUTPUT_DELAY   [expr {$CLK_CORE_PERIOD_ACTUAL *1* $OUTPUT_DELAY_GAIN_LOW}]
} else {
  set CLK_CORE_INPUT_DELAY    [expr {$CLK_CORE_PERIOD_ACTUAL *1* $INPUT_DELAY_GAIN}]
  set CLK_CORE_OUTPUT_DELAY   [expr {$CLK_CORE_PERIOD_ACTUAL *1* $OUTPUT_DELAY_GAIN}]
}
if {$CLK_BPU_PERIOD_ACTUAL > 10} {
  set CLK_BPU_INPUT_DELAY     [expr {$CLK_BPU_PERIOD_ACTUAL  *1* $INPUT_DELAY_GAIN_LOW}]
  set CLK_BPU_OUTPUT_DELAY    [expr {$CLK_BPU_PERIOD_ACTUAL  *1* $OUTPUT_DELAY_GAIN_LOW}]
} else {
  set CLK_BPU_INPUT_DELAY     [expr {$CLK_BPU_PERIOD_ACTUAL  *1* $INPUT_DELAY_GAIN}]
  set CLK_BPU_OUTPUT_DELAY    [expr {$CLK_BPU_PERIOD_ACTUAL  *1* $OUTPUT_DELAY_GAIN}]
}
if {$CLK_BUS_PERIOD_ACTUAL > 10} {
  set CLK_BUS_INPUT_DELAY     [expr {$CLK_BUS_PERIOD_ACTUAL  *1* $INPUT_DELAY_GAIN_LOW}]
  set CLK_BUS_OUTPUT_DELAY    [expr {$CLK_BUS_PERIOD_ACTUAL  *1* $OUTPUT_DELAY_GAIN_LOW}]
} else {
  set CLK_BUS_INPUT_DELAY     [expr {$CLK_BUS_PERIOD_ACTUAL  *1* $INPUT_DELAY_GAIN}]
  set CLK_BUS_OUTPUT_DELAY    [expr {$CLK_BUS_PERIOD_ACTUAL  *1* $OUTPUT_DELAY_GAIN}]
}


set_input_delay    $CLK_HOST_INPUT_DELAY   -clock CLOCK_HOST  [get_ports i_host_apb_*]
set_output_delay   $CLK_HOST_OUTPUT_DELAY  -clock CLOCK_HOST  [get_ports o_host_apb_*]
 
set_output_delay   $CLK_CORE_OUTPUT_DELAY  -clock CLOCK_CORE   [get_ports o_vpu_*]
set_output_delay   $CLK_CORE_OUTPUT_DELAY  -clock CLOCK_CORE   [get_ports o_uart_txsout]
set_input_delay    $CLK_CORE_INPUT_DELAY   -clock CLOCK_CORE   [get_ports i_uart_rxsin]



set_input_delay    $CLK_HOST_INPUT_DELAY   -clock CLOCK_HOST  [get_ports pre*]
set_input_delay    $CLK_HOST_INPUT_DELAY   -clock CLOCK_HOST  [get_ports post*]
set_input_delay    $CLK_HOST_INPUT_DELAY   -clock CLOCK_HOST  [get_ports sec*]

#-------------------------------------------------------------------------------
# Set bus input/ouptut delay
#-------------------------------------------------------------------------------
set_output_delay   $CLK_BUS_OUTPUT_DELAY   -clock CLOCK_BUS   [get_ports o_*_axi_*]
set_input_delay    $CLK_BUS_INPUT_DELAY    -clock CLOCK_BUS   [get_ports i_*_axi_*]


#set_output_delay   $CLK_BPU_OUTPUT_DELAY   -clock CLOCK_BPU   [get_ports monitor_*]


#--------------------------------------------------------------------
# Set Group Path for Input / Output / Feedthrough 
#--------------------------------------------------------------------
set ports_clock_root [get_ports [all_fanout -flat -clock_tree -level 0]]
group_path -name REGOUT -to [all_outputs]
group_path -name REGIN -from [remove_from_collection [all_inputs] $ports_clock_root]
group_path -name FEEDTHROUGH  -from [remove_from_collection [all_inputs] $ports_clock_root] \
                              -to [all_outputs]
