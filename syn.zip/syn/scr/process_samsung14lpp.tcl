###############################################################################
# SAMSUNG 14lpp
###############################################################################
set LIB_PATH  [list \
/Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_base_rvt_c16/r1p1/db-ccs-tn-scm \
/Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_hpk_rvt_c16/r1p0/db-ccs-tn-scm  \
/Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_base_rvt_c14/r1p1/db-ccs-tn-scm \
/Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_hpk_rvt_c14/r1p0/db-ccs-tn-scm  \
/Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_base_lvt_c14/r1p1/db-ccs-tn-scm \
/Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_hpk_lvt_c14/r1p0/db-ccs-tn-scm  \
/Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_base_lvt_c16/r1p1/db-ccs-tn-scm \
/Foundry/ARM/samsung_14lpp/Standard_Cell/arm/samsung/14lpp/sc9mcpp84_hpk_lvt_c16/r1p0/db-ccs-tn-scm  \
/Foundry/ARM/samsung_14lpp/Standard_IO/ln14lpp_gpio_1p8v_V1.21_pkg/FE-Common_sec230126_0019/LIBERTY/synopsys \
/Foundry/ARM/samsung_14lpp/Standard_IO/ln14lpp_gpio_3p3v_V1.10_pkg/FE-Common_sec230126_0020/LIBERTY/synopsys \
/Foundry/ARM/samsung_14lpp/Standard_IO/ln14lpp_power_1p8v_m11_V1.04_pkg/FE-Common_sec230818_0015/LIBERTY \
/Foundry/ARM/samsung_14lpp/Standard_IO/efuse/20230711_bk/sf_efuse4kb_v100_ln14lpp_34000_V1.02_pkg/FE-Common_sec210531_0125/LIBERTY/synopsys \
$G2_RTL/scp/syn_lib/db \
$G2_RTL/risc_v/syn_lib/db \
$G2_RTL/lowspeed/syn_lib/db \
              ]

set_app_var search_path         [concat $search_path $LIB_PATH] 
set_app_var synthetic_library   [list dw_foundation.sldb standard.sldb]

#--------- Logic library
set LIB_EXT             "db"

# define MEMORY DEFINE for the libaray
#set MEM_DEF_LIST        CNM_TSMC28HPC
if {![info exist USE_PWR_RPT]}      { set USE_PWR_RPT   0 } 
if {![info exist USE_MIXED_LIB]}    { set USE_MIXED_LIB 0 } 
if {![info exist USE_LIB_M40]}      { set USE_LIB_M40   1 } 



set_app_var target_library  [list \
                                                        sc9mcpp84_14lpp_base_rvt_c16_ssa_sigcmax_max_0p72v_m40c.db_ccs_tn_sh5cm \
                                                        sc9mcpp84_14lpp_hpk_rvt_c16_ssa_sigcmax_max_0p72v_m40c.db_ccs_tn_sh5cm \
                                                        sc9mcpp84_14lpp_base_rvt_c14_ssa_sigcmax_max_0p72v_m40c.db_ccs_tn_sh5cm \
                                                        sc9mcpp84_14lpp_hpk_rvt_c14_ssa_sigcmax_max_0p72v_m40c.db_ccs_tn_sh5cm \
                                                        sc9mcpp84_14lpp_base_lvt_c14_ssa_sigcmax_max_0p72v_m40c.db_ccs_tn_sh5cm \
                                                        sc9mcpp84_14lpp_hpk_lvt_c14_ssa_sigcmax_max_0p72v_m40c.db_ccs_tn_sh5cm \
                                                        sc9mcpp84_14lpp_base_lvt_c16_ssa_sigcmax_max_0p72v_m40c.db_ccs_tn_sh5cm \
                                                        sc9mcpp84_14lpp_hpk_lvt_c16_ssa_sigcmax_max_0p72v_m40c.db_ccs_tn_sh5cm \
io_gppr_ln14lpp_t18_ee_ss_Cmax_0p720v_1p620v_m40c.db \
io_gppr_ln14lpp_t33_ee_ss_nominal_0p720v_1p620v_2p970v_m40c.db \
esd_gppr_ln14lpp_t18_ee_ss_nominal_0p720v_1p620v_m40c.db \
CPU_S14_RAM_SP_4096X32_ssa_sigcmax_0p72v_0p72v_m40c.db \
CPU_S14_ROM_SP_4096X32_ssa_sigcmax_0p72v_0p72v_m40c.db \
EC_S14_RAM_SP_128X32_ssa_sigcmax_0p72v_0p72v_m40c.db \
SE_ACA_S14_RAM_SP_512X128_ssa_sigcmax_0p72v_0p72v_m40c.db \
SE_CXT_S14_RAM_SP_528X32_ssa_sigcmax_0p72v_0p72v_m40c.db \
INNO_FNPLL_TOP_ss_rcmax_m40.db \
inno_por_ip_ss_rcmax_m40_func.db \
sf_efuse_hd_v101_ln14lpp_34000_ss_0p720v_m40c.db \
inno_puf_64b_ip_ss_rcmax_m40.db \
                                                        ]

set_app_var link_library "* $target_library $synthetic_library"

                
