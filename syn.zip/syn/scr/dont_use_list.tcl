if { $TLIB_NAME == "samsung8lpp"} {
set_dont_use [get_lib_cells */*TIE*]
set_dont_use [get_lib_cells */*DEL*]
set_dont_use [get_lib_cells */*AOI2222*]
set_dont_use [get_lib_cells */*F*D*M8*]
set_dont_use [get_lib_cells */*ECOCT*]
set_dont_use [get_lib_cells */*CK*]
set_dont_use [get_lib_cells */*_MM*]
set_dont_use [get_lib_cells */*_SDC*]
set_dont_use [get_lib_cells */*_S_*]
set_dont_use [get_lib_cells */*_20*]
set_dont_use [get_lib_cells */*_24*]
set_dont_use [get_lib_cells */*_32*]
} 

if { $TLIB_NAME == "tsmc12ffc"} {
set_dont_use [get_lib_cells */*D20*]
set_dont_use [get_lib_cells */*D24*]
set_dont_use [get_lib_cells */*D28*]
set_dont_use [get_lib_cells */*D32*]
set_dont_use [get_lib_cells */*D36*]

# Delay cells
set_dont_use [get_lib_cells */*DEL*]

# Tie cells
set_dont_use [get_lib_cells */TIE*]

# ECO cells
set_dont_use [get_lib_cells */G*]

set_dont_use [get_lib_cells */CK*]

set_dont_use [get_lib_cells */*OPT*]
set_dont_use [get_lib_cells */*DFKCS*]
set_dont_use [get_lib_cells */*DFCS*]
set_dont_use [get_lib_cells */*DFNCS*]
set_dont_use [get_lib_cells */*EDF*]
set_dont_use [get_lib_cells */*DFM*]


remove_attribute [get_lib_cells */CKLNQD4BWP6T16P96CPDLVT] pwr_cg_dont_use
remove_attribute [get_lib_cells */CKLNQD6BWP6T16P96CPDLVT] pwr_cg_dont_use
remove_attribute [get_lib_cells */CKLNQD8BWP6T16P96CPDLVT] pwr_cg_dont_use
remove_attribute [get_lib_cells */CKLNQD12BWP6T16P96CPDLVT] pwr_cg_dont_use
remove_attribute [get_lib_cells */CKLNQD4BWP6T20P96CPDLVT] pwr_cg_dont_use
remove_attribute [get_lib_cells */CKLNQD6BWP6T20P96CPDLVT] pwr_cg_dont_use
remove_attribute [get_lib_cells */CKLNQD8BWP6T20P96CPDLVT] pwr_cg_dont_use
remove_attribute [get_lib_cells */CKLNQD12BWP6T20P96CPDLVT] pwr_cg_dont_use
}
