#=============================================================================
#
#       This confidential and proprietary software may be used only
#     as authorized by a licensing agreement from Chips&Media Inc.
#     In the event of publication, the following notice is applicable:
#
#                    (C) COPYRIGHT 2003 - 2011   CHIPS&MEDIA INC.
#                           ALL RIGHTS RESERVED
#
#       The entire notice above must be reproduced on all authorized
#     copies.
#
#=============================================================================
#
# File         : $Id: clock_constraints.tcl 145466 2018-04-24 11:18:07Z ethan.kim $
# Author(s)    : WAVE51x
# Modifier     : $LastChangedBy: ethan.kim $
# Description  : Clock and IO definition
#=============================================================================
#       CLOCK DEFINITION 
#------------------------------------------------
set CLK_HOST_PERIOD  [expr {1000.0/($CLK_HOST_FREQ * $FREQ_MARGIN)}]
set CLK_CORE_PERIOD  [expr {1000.0/($CLK_CORE_FREQ * $FREQ_MARGIN)}]
set CLK_BPU_PERIOD   [expr {1000.0/($CLK_BPU_FREQ  * $FREQ_MARGIN)}]
set CLK_BUS_PERIOD   [expr {1000.0/($CLK_BUS_FREQ  * $FREQ_MARGIN)}]
set CLK_HOST_PERIOD_ACTUAL  [expr {1000.0/($CLK_HOST_FREQ * 1)}]
set CLK_CORE_PERIOD_ACTUAL  [expr {1000.0/($CLK_CORE_FREQ * 1)}]
set CLK_BPU_PERIOD_ACTUAL   [expr {1000.0/($CLK_BPU_FREQ  * 1)}]
set CLK_BUS_PERIOD_ACTUAL   [expr {1000.0/($CLK_BUS_FREQ  * 1)}]


create_clock [get_ports "pclk"] -name CLOCK_HOST    -period $CLK_HOST_PERIOD
# create_clock [get_ports "bclk"] -name CLOCK_BPU     -period $CLK_BPU_PERIOD
create_clock [get_ports "cclk"] -name CLOCK_CORE    -period $CLK_CORE_PERIOD
create_clock [get_ports "aclk"] -name CLOCK_BUS     -period $CLK_BUS_PERIOD


set_ideal_network [get_ports "pclk"]
set_ideal_network [get_ports "aclk"]
# set_ideal_network [get_ports "bclk"]
set_ideal_network [get_ports "cclk"]

#================================================
#       RESERT CONDITIONS
#------------------------------------------------
set RESET_NETS {preset_n areset_n creset_n}
foreach RESET_NET $RESET_NETS {
    echo "Make exception network for delay & power: $RESET_NET"
#    set_false_path -from [get_ports $RESET_NET]
    set_multicycle_path 4 -setup -from [get_ports $RESET_NET]
    set_multicycle_path 3 -hold -from [get_ports $RESET_NET]
    set_drive 0 [get_ports $RESET_NET]
    set_resistance 0.0 [get_nets $RESET_NET]
    set_dont_touch_network [get_ports $RESET_NET]
}

set_false_path -from [get_ports i_test_mode]
set_ideal_network [get_ports i_test_mode] -no_propagate


set_false_path -through [get_ports o_vpu_intr*]
set_resistance 0.0 [get_nets "o_vpu_intr*"]
set_ideal_network [get_ports o_vpu_intr*] -no_propagate
set_dont_touch_network [get_ports o_vpu_intr*]

#set_false_path -to   [get_ports monitor_*]
#set_ideal_network [get_ports monitor_*] -no_propagate

#================================================
#       FALSE PATH
#------------------------------------------------
## False path for gated clock
# below command declare the clock is asynchronous to all others
set_clock_groups  -asynchronous -name asynch  -group [get_clocks CLOCK_HOST] \
                                              -group [get_clocks CLOCK_BUS]  \
                                              -group [get_clocks CLOCK_CORE]


#================================================
#       setup Skew
#------------------------------------------------
if { $USE_SKEW_MARGIN == 1 } {
    set CLK_HOST_SKEW [expr {$CLK_HOST_PERIOD_ACTUAL * $SKEW_RATIO}]
    set CLK_CORE_SKEW [expr {$CLK_CORE_PERIOD_ACTUAL * $SKEW_RATIO}]
    set CLK_BUS_SKEW  [expr {$CLK_BUS_PERIOD_ACTUAL  * $SKEW_RATIO}]

    set_clock_uncertainty $CLK_HOST_SKEW    [get_clocks CLOCK_HOST]
    set_clock_uncertainty $CLK_CORE_SKEW    [get_clocks CLOCK_CORE]
    set_clock_uncertainty $CLK_BUS_SKEW     [get_clocks CLOCK_BUS]
}
