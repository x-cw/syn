# sdc_start
#PLL clock
#set GPU_PERIOD                    [expr 1000.0 / 950 ]
set GPU_PERIOD                    [expr 1000.0 / 1000 ]
set GDDR_PERIOD                   [expr 1000.0 / 1200 ]
set PCIE_PERIOD                   [expr 1000.0 / 800  ]
#set DMA_PERIOD                    [expr 1000.0 / 700  ]
set DMA_PERIOD                    1.428
#set VDEC_BCLK_PERIOD              [expr 1000.0 / 650  ]
#set VDEC_CCLK_PERIOD              [expr 1000.0 / 650  ]
#set VENC_CCLK_PERIOD              [expr 1000.0 / 650  ]
set VDEC_BCLK_PERIOD              1.538
set VDEC_CCLK_PERIOD              1.538
set VENC_CCLK_PERIOD              [expr 1000.0 / 800 ]
set PDP_PERIOD                    [expr 1000.0 / 800 ]
set EFUSE_PERIOD                  [expr 1000.0 / 1000 ]
set DBUS_PERIOD                   [expr 1000.0 / 1000 ]
set CBUS_PERIOD                   [expr 1000.0 / 250  ]
set SCP_PERIOD                    [expr 1000.0 / 500  ]
#set VGA_PERIOD                    [expr 1000.0 / 600  ]
set VGA_PERIOD                    1.666
set AUDIO_PERIOD                  [expr 1000.0 / 100  ]
set FRAC_DUMMY_PERIOD             [expr 1000.0 / 1000  ]



set PCIE_PHY_PERIOD               [expr 1000.0 / 100  ]
#set PCIE_PHY_333M_PERIOD               [expr 1000.0 / 333  ]
#set PCIE_PHY_1G_PERIOD               [expr 1000.0 / 1000  ]
#set PCIE_PHY_2G_PERIOD               [expr 1000.0 / 2000  ]

#ref and pinmux clock
set REFCLK_PERIOD                 [expr 1000.0 / 50   ]
set CLK_TS_PERIOD                 [expr 1000.0 / 50   ]
#set IP_TEST_PERIOD               [expr 1000.0 / 10  ]
set DELAY 60
set LOW_DELAY 40

set clk_gen_hier  scp_top_inst/clk_gen_inst
set scp_top_hier  scp_top_inst
set low_speed_hier  low_speed_misc_wrap_inst
set reset_ctrl_hier scp_top_inst/reset_ctrl_inst
set trust_engine_hier trust_engine_wrapper_inst


#todo driving cell
#set_driving_cell -lib_cell  BUF_D4_N_S7P94TL_C60L06 -pin Y -no_design_rule [all_inputs]


#set_input_transition -max 1  [get_ports PADS* -filter "port_direction =~ in || port_direction =~ inout"]
#set_input_transition -min 0.1  [get_ports PADS* -filter "port_direction =~ in || port_direction =~ inout"]
#set_load -max 20  [get_ports PADS*]
#set_load -min 2  [get_ports PADS*]





##function mode
set_case_analysis 0 [get_ports "PADS_MODE*"]
#TODO
#set_case_analysis 0 [get_pins scp_top_inst/gp3_io_inst/u_gp3_pad/dont_touch_block_pads_inst1/gp3_pad_sps]
#set_ideal_network -no_propagate [get_ports "*rstn* *reset* trig_pcie*_button"]


#################################source clock###################
create_clock -name "pll_gpua_clk"       -period "$GPU_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_gpua/inno_pll_frac_inst/clko0"]
create_clock -name "pll_gpub_clk"       -period "$GPU_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_gpub/inno_pll_frac_inst/clko0"]
create_clock -name "pll_gddr_clk"       -period "$GDDR_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_gddr/inno_pll_frac_inst/clko0"]
create_clock -name "pll_pcie_clk"        -period "$PCIE_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_pcie/inno_pll_frac_inst/clko0"]
create_clock -name "pll_pcie_phy_clk"    -period "$PCIE_PHY_PERIOD"      [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_pcie/inno_pll_frac_inst/clko1"]
create_clock -name "pll_dma_clk"        -period "$DMA_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_dma/inno_pll_frac_inst/clko0"]
create_clock -name "pll_vdec_bclk"     -period "$VDEC_BCLK_PERIOD"     [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_vdec_bclk/inno_pll_frac_inst/clko0"]
create_clock -name "pll_vdec_cclk"     -period "$VDEC_CCLK_PERIOD"        [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_vdec_cclk/inno_pll_frac_inst/clko0"]
create_clock -name "pll_venc_cclk"     -period "$VENC_CCLK_PERIOD"        [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_venc_cclk/inno_pll_frac_inst/clko0"]
create_clock -name "pll_pdp_clk"       -period "$PDP_PERIOD"            [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_pdp/inno_pll_frac_inst/clko0"]
create_clock -name "pll_databus_clk"    -period "$DBUS_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_databus/inno_pll_frac_inst/clko0"]
#create_clock -name "pll_cfgbus_clk"     -period "$CBUS_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_cfgbus/inno_pll_frac_inst/clko0"]
create_clock -name "pll_efuse_clk"     -period "$EFUSE_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_scp/inno_pll_frac_inst/clko0"]
create_clock -name "pll_scp_clk"        -period "$SCP_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_scp/inno_pll_frac_inst/clko1"]
create_clock -name "pll_vga_clk"        -period "$VGA_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_vga/inno_pll_frac_inst/clko0"]
create_clock -name "pll_audio_a_clk"        -period "$AUDIO_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_a/inno_pll_frac_inst/clko0"]
create_clock -name "pll_audio_b_clk"        -period "$AUDIO_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_b/inno_pll_frac_inst/clko0"]
#create_clock -name "pll_int_dummy_clk"  -period "$INT_DUMMY_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_int_dummy/inno_pll_frac_inst/clko0"]
create_clock -name "pll_frac_dummy_clk"  -period "$FRAC_DUMMY_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_frac_dummy/inno_pll_frac_inst/clko0"]

create_clock -name "ref_clk"            -period $REFCLK_PERIOD          [get_pins "$clk_gen_hier/PADS_REF_CLK_inst/Y"]

#TODO function  mode have no clock
create_clock -name "LSP_JTAG_CLK" [get_pins "$scp_top_hier/g2_io_inst/u_g2_pad/pads_lsp_jtag_tclk_inst/Y"]    -period "${CLK_TS_PERIOD}" 
create_clock -name "CPU_JTAG_CLK" [get_pins "$scp_top_hier/g2_io_inst/u_g2_pad/pads_cpu_jtag_tclk_inst/Y"]  -period "${CLK_TS_PERIOD}"




##################################generate clock###################
create_generated_clock -name CLK_POR_0  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_0_/Q ] -divide_by 2 -source [get_pins $clk_gen_hier/PADS_REF_CLK_inst/Y]
create_generated_clock -name CLK_POR_1  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_1_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_0_/Q]
create_generated_clock -name CLK_POR_2  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_2_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_1_/Q]
create_generated_clock -name CLK_POR_3  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_3_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_2_/Q]
create_generated_clock -name CLK_POR_4  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_4_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_3_/Q]
create_generated_clock -name CLK_POR_5  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_5_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_4_/Q]
create_generated_clock -name CLK_POR_6  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_6_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_5_/Q]
create_generated_clock -name CLK_POR_7  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_7_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_6_/Q]
create_generated_clock -name CLK_POR_8  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_8_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_7_/Q]
create_generated_clock -name CLK_POR_9  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_9_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_8_/Q]
create_generated_clock -name CLK_POR_10 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_10_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_9_/Q]
create_generated_clock -name CLK_POR_11 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_11_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_10_/Q]
create_generated_clock -name CLK_POR_12 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_12_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_11_/Q]
create_generated_clock -name CLK_POR_13 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_13_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_12_/Q]
create_generated_clock -name CLK_POR_14 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_14_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_13_/Q]
create_generated_clock -name CLK_POR_15 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_15_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_14_/Q]

#freq_div


create_generated_clock -name "mbist_repair_clk"   [get_pins "$clk_gen_hier/freq_div_inst.mbist_repair_clk_div4_inst/fout_pre_reg/Q"] -divide_by 4 -add -master_clock "ref_clk"        -source [get_pins "$clk_gen_hier/PADS_REF_CLK_inst/Y"]
create_generated_clock -name "dft_test_clk_300m"   [get_pins "$clk_gen_hier/freq_div_inst.dft_test_clk_300m_div2_inst/fout_pre_reg/Q"] -divide_by 2 -add -master_clock "pll_vga_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_vga/inno_pll_frac_inst/clko0"]
create_generated_clock -name "dft_apb_clk"        [get_pins "$clk_gen_hier/freq_div_inst.pll_dft_apb_clk_div4_inst/fout_pre_reg/Q"]  -divide_by 4 -add -master_clock "ref_clk"        -source [get_pins "$clk_gen_hier/PADS_REF_CLK_inst/Y"]
create_generated_clock -name "pdp_div_clk_400m"   [get_pins "$clk_gen_hier/freq_div_inst.pdp_div_clk_400m_div2_inst/fout_pre_reg/Q"] -divide_by 2 -add -master_clock "pll_pdp_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_pdp/inno_pll_frac_inst/clko0"]
create_generated_clock -name "hdmi_timclk"   [get_pins "$clk_gen_hier/freq_div_inst.hdmi_timclk_200m_div2_inst/fout_pre_reg/Q"] -divide_by 2 -add -master_clock "pdp_div_clk_400m"        -source [get_pins "$clk_gen_hier/freq_div_inst.pdp_div_clk_400m_div2_inst/fout_pre_reg/Q"]

create_generated_clock -name "gpua_test_clk" [get_pins "$clk_gen_hier/freq_div_inst.pll_gpua_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_gpua_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_gpua/inno_pll_frac_inst/clko0"]
create_generated_clock -name "gpub_test_clk" [get_pins "$clk_gen_hier/freq_div_inst.pll_gpub_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_gpub_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_gpub/inno_pll_frac_inst/clko0"]
create_generated_clock -name "gddr_test_clk" [get_pins "$clk_gen_hier/freq_div_inst.pll_gddr_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_gddr_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_gddr/inno_pll_frac_inst/clko0"]
create_generated_clock -name "pcie_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_pcie_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_pcie_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_pcie/inno_pll_frac_inst/clko0"]
create_generated_clock -name "dma_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_dma_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_dma_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_dma/inno_pll_frac_inst/clko0"]
create_generated_clock -name "vdec_bclk_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_vdec_bclk_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_vdec_bclk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_vdec_bclk/inno_pll_frac_inst/clko0"]
create_generated_clock -name "vdec_cclk_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_vdec_cclk_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_vdec_cclk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_vdec_cclk/inno_pll_frac_inst/clko0"]
create_generated_clock -name "venc_cclk_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_venc_cclk_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_venc_cclk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_venc_cclk/inno_pll_frac_inst/clko0"]
create_generated_clock -name "pdp_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_pdp_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_pdp_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_pdp/inno_pll_frac_inst/clko0"]
create_generated_clock -name "efuse_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_efuse_test_clk_div_n/fout_pre_reg/Q"]   -divide_by 32 -add -master_clock "pll_efuse_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_scp/inno_pll_frac_inst/clko0"]
#create_generated_clock -name "cfgbus_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_cfgbus_test_clk_div_n/fout_pre_reg/Q"]   -divide_by 32 -add -master_clock "pll_cfgbus_clk" -source  [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_cfgbus/inno_pll_frac_inst/clko0"]
create_generated_clock -name "databus_test_clk" [get_pins "$clk_gen_hier/freq_div_inst.pll_databus_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_databus_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_databus/inno_pll_frac_inst/clko0"]
create_generated_clock -name "scp_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_scp_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_scp_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_scp/inno_pll_frac_inst/clko1"]
create_generated_clock -name "vga_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_vga_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_vga_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_vga/inno_pll_frac_inst/clko0"]
create_generated_clock -name "audio_a_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_audio_a_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_audio_a_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_a/inno_pll_frac_inst/clko0"]
create_generated_clock -name "audio_b_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst.pll_audio_b_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_audio_b_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_b/inno_pll_frac_inst/clko0"]
create_generated_clock -name "pcie_phy_test_clk" [get_pins "$clk_gen_hier/freq_div_inst.pll_pcie_phy_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_pcie_phy_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_pcie/inno_pll_frac_inst/clko1"]
#create_generated_clock -name "int_dummy_test_clk" [get_pins "$clk_gen_hier/freq_div_inst.pll_int_dummy_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_int_dummy_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_int_dummy/inno_pll_frac_inst/clko0"]
create_generated_clock -name "frac_dummy_test_clk" [get_pins "$clk_gen_hier/freq_div_inst.pll_frac_dummy_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_frac_dummy_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_frac_dummy/inno_pll_frac_inst/clko0"]


create_generated_clock -name "cfgbus_clk"        [get_pins "$clk_gen_hier/freq_div_inst.cfgbus_clk_div2_inst/fout_pre_reg/Q"]  -divide_by 2 -add -master_clock "pll_scp_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_scp/inno_pll_frac_inst/clko1"]

create_generated_clock -name "clk_to_lowspeed"        [get_pins "$clk_gen_hier/freq_div_inst.freq_div_2n_lowspeed/fout_pre_reg/Q"]  -divide_by 2 -add -master_clock "pll_scp_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_scp/inno_pll_frac_inst/clko1"]

create_generated_clock -name "clk_to_rom"        [get_pins "$clk_gen_hier/freq_div_inst.freq_div_2n_rom/fout_pre_reg/Q"]  -divide_by 2 -add -master_clock "pll_scp_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_scp/inno_pll_frac_inst/clko1"]

create_generated_clock -name "gpio_ref_clk_0"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst.freq_div_2n_gpio_db_ref_clk_inst0/fout_pre_reg/Q ] -divide_by 2 -source [get_pins $clk_gen_hier/PADS_REF_CLK_inst/Y]
create_generated_clock -name "gpio_ref_clk_1"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst.freq_div_2n_gpio_db_ref_clk_inst1/fout_pre_reg/Q ] -divide_by 2 -source [get_pins  $scp_top_hier/clk_gen_inst/freq_div_inst.freq_div_2n_gpio_db_ref_clk_inst0/fout_pre_reg/Q ]
create_generated_clock -name "gpio_ref_clk_2"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst.freq_div_2n_gpio_db_ref_clk_inst2/fout_pre_reg/Q ] -divide_by 2 -source [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst.freq_div_2n_gpio_db_ref_clk_inst1/fout_pre_reg/Q]


create_generated_clock -name "ec_ref_clk_0"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst.freq_div_2n_ec_db_ref_clk_inst0/fout_pre_reg/Q ] -divide_by 2 -source [get_pins $clk_gen_hier/PADS_REF_CLK_inst/Y]
create_generated_clock -name "ec_ref_clk_1"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst.freq_div_2n_ec_db_ref_clk_inst1/fout_pre_reg/Q ] -divide_by 2 -source [get_pins  $scp_top_hier/clk_gen_inst/freq_div_inst.freq_div_2n_ec_db_ref_clk_inst0/fout_pre_reg/Q ]




create_generated_clock -name "qspi_clk" [get_pins "$low_speed_hier/qspi_wrapper_u/DWC_ssi_inst/U_sclkgen/sclk_out_reg/Q"] -divide_by 2 -add -master_clock "clk_to_lowspeed"  -source [get_pins "$clk_gen_hier/freq_div_inst.freq_div_2n_lowspeed/fout_pre_reg/Q"]


create_generated_clock -name "CLK_QSPI_PAD" [get_pins "$scp_top_hier/g2_io_inst/u_g2_pad/pads_flash_clk_inst/PAD"] -add -master_clock "qspi_clk" -divide_by 1 -source [get_pins "$low_speed_hier/qspi_wrapper_u/DWC_ssi_inst/U_sclkgen/sclk_out_reg/Q"]





# CRM
create_generated_clock -name "dbus_noc_clk"  [get_pins "$reset_ctrl_hier/crm_inst.noc_crm_dbus_noc/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_databus_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_databus/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "cbus_noc_clk"  [get_pins "$reset_ctrl_hier/crm_inst.noc_crm_cbus_noc/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "cfgbus_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/freq_div_inst.cfgbus_clk_div2_inst/fout_pre_reg/Q"] 
create_generated_clock -name "tcu_clk"  [get_pins "$reset_ctrl_hier/crm_inst.noc_crm_tcu/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_databus_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_databus/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio0_a_clk"  [get_pins "$reset_ctrl_hier/crm_inst.noc_crm_audio0_a/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_a_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_a/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio0_b_clk"  [get_pins "$reset_ctrl_hier/crm_inst.noc_crm_audio0_b/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_b_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_b/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio1_a_clk"  [get_pins "$reset_ctrl_hier/crm_inst.noc_crm_audio1_a/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_a_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_a/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio1_b_clk"  [get_pins "$reset_ctrl_hier/crm_inst.noc_crm_audio1_b/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_b_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_b/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio2_a_clk"  [get_pins "$reset_ctrl_hier/crm_inst.noc_crm_audio2_a/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_a_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_a/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio2_b_clk"  [get_pins "$reset_ctrl_hier/crm_inst.noc_crm_audio2_b/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_b_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_audio_b/inno_pll_frac_inst/clko0"] 





#############others
create_generated_clock -name CLK_PLL_DETECT_DEST [get_pins $clk_gen_hier/clock_freq_measure_inst/pll_detect_clk_sel_u/cell_clk_or4_u4/dont_touch_clk_or_u/Y]  -master_clock "pll_databus_clk" -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst.pll_wrapper_databus/inno_pll_frac_inst/clko0"]




#####################switch stop
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_gpub_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_pll_gpu_ping_pong/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_gddr/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_pcie/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_dma/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_vdec_bclk/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_vdec_cclk/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_venc_cclk/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_pdp/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_efuse/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
#set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_cfgbus/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_databus/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_scp/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_vga/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_audio_a/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch3_audio_b/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]

set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch2_pcie_phy/clk_out_cell/dont_touch_clk_or_u/Y"]


##phy clock for test and measure
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk pll_pcie_phy_clk pll_audio_b_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst.clk_switch2_pll_others_clkout_inst/clk_out_cell/dont_touch_clk_or_u/Y"]
    

## pll clock switch
set_sense -type clock -stop_propagation  -clocks  [get_clocks "ref_clk"] [get_pins  "$clk_gen_hier/pll_wrap_inst.pll_wrapper_*/clk_switch_pll_bypass*/clk_out_cell/dont_touch_clk_or_u/Y"]

#set_clock_exclusivity -type user_defined -output "$scp_top_hier/clk_gen_inst/pll_wrap_inst.pll_wrapper_frac_dummy/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/Y" -input "$scp_top_hier/clk_gen_inst/pll_wrap_inst.pll_wrapper_frac_dummy/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/A $scp_top_hier/clk_gen_inst/pll_wrap_inst.pll_wrapper_frac_dummy/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/B"


set_clock_groups -asynchronous \
  -group [get_clocks "pll_gpua_clk"] \
  -group [get_clocks "pll_gpub_clk"] \
  -group [get_clocks "pll_gddr_clk "] \
  -group [get_clocks "pll_pcie_clk"] \
  -group [get_clocks "pll_dma_clk"] \
  -group [get_clocks "pll_vdec_bclk "] \
  -group [get_clocks "pll_vdec_cclk "] \
  -group [get_clocks "pll_venc_cclk "] \
  -group [get_clocks "pll_pdp_clk pdp_div_clk_400m hdmi_timclk"] \
  -group [get_clocks "pll_efuse_clk CLK_PLL_DETECT_DEST"] \
  -group [get_clocks "pll_databus_clk"] \
  -group [get_clocks "pll_scp_clk clk_to_lowspeed CLK_QSPI_PAD qspi_clk clk_to_rom"] \
  -group [get_clocks "cfgbus_clk"] \
  -group [get_clocks "pll_vga_clk"] \
  -group [get_clocks "pll_audio_a_clk"] \
  -group [get_clocks "pll_audio_b_clk"] \
  -group [get_clocks "pll_frac_dummy_clk"] \
  -group [get_clocks "ref_clk gpio_ref_clk_0 gpio_ref_clk_1 gpio_ref_clk_2 ec_ref_clk_0 ec_ref_clk_1"] \
  -group [get_clocks "pll_pcie_phy_clk"] \
  -group [get_clocks "LSP_JTAG_CLK "] \
  -group [get_clocks "CPU_JTAG_CLK"] \
  -group [get_clocks "CLK_POR_*"] \
  -group [get_clocks "pcie_phy_test_clk"] \
  -group [get_clocks "mbist_repair_clk"] \
  -group [get_clocks "dft_test_clk_300m"] \
  -group [get_clocks "dft_apb_clk"] \
  -group [get_clocks "gpua_test_clk"] \
  -group [get_clocks "gpub_test_clk"] \
  -group [get_clocks "gddr_test_clk"] \
  -group [get_clocks "pcie_test_clk"] \
  -group [get_clocks "dma_test_clk"] \
  -group [get_clocks "vdec_bclk_test_clk"] \
  -group [get_clocks "vdec_cclk_test_clk"] \
  -group [get_clocks "venc_cclk_test_clk"] \
  -group [get_clocks "pdp_test_clk"] \
  -group [get_clocks "efuse_test_clk"] \
  -group [get_clocks "databus_test_clk"] \
  -group [get_clocks "scp_test_clk"] \
  -group [get_clocks "vga_test_clk"] \
  -group [get_clocks "audio_a_test_clk"] \
  -group [get_clocks "audio_b_test_clk"] \
  -group [get_clocks "frac_dummy_test_clk"] \
  -group [get_clocks "dbus_noc_clk"] \
  -group [get_clocks "cbus_noc_clk"] \
  -group [get_clocks "tcu_clk"] \
  -group [get_clocks "audio0_a_clk"] \
  -group [get_clocks "audio0_b_clk"] \
  -group [get_clocks "audio1_a_clk"] \
  -group [get_clocks "audio1_b_clk"] \
  -group [get_clocks "audio2_a_clk"] \
  -group [get_clocks "audio2_b_clk"]  

# sdc_inout_start

set reset_crm [get_pins -of [get_cells $reset_ctrl_hier/crm_inst.noc_crm_*/*  -filter "full_name =~ */pre_rst_n_sync_1*"] -filter "full_name =~ *CK"]
if {[get_pins $reset_crm ] != ""} {
        set_multicycle_path -from ${reset_crm} -setup 4 -start
       set_multicycle_path -from ${reset_crm} -hold  3 -start
}

# inout port
set_input_delay   [expr $CLK_TS_PERIOD * ($DELAY/100.0)] -clock "CPU_JTAG_CLK" [get_ports "PADS_CPU_JTAG_RSTN PADS_CPU_JTAG_TDI PADS_CPU_JTAG_TMS PADS_CPU_JTAG_TCLK PADS_CPU_JTAG_TDO"] -add
set_output_delay  [expr $CLK_TS_PERIOD * ($DELAY/100.0)] -clock "CPU_JTAG_CLK" [get_ports "PADS_CPU_JTAG_RSTN PADS_CPU_JTAG_TDI PADS_CPU_JTAG_TMS PADS_CPU_JTAG_TCLK PADS_CPU_JTAG_TDO"] -add

set_input_delay   [expr $CLK_TS_PERIOD * ($DELAY/100.0)] -clock "LSP_JTAG_CLK" [get_ports "PADS_LSP_JTAG_RSTN PADS_LSP_JTAG_TDI PADS_LSP_JTAG_TMS PADS_LSP_JTAG_TCLK"] -add
set_output_delay  [expr $CLK_TS_PERIOD * ($DELAY/100.0)] -clock "LSP_JTAG_CLK" [get_ports "PADS_LSP_JTAG_TDO"] -add

set_input_delay   [ expr $SCP_PERIOD* ($DELAY/100.0) ] -clock "pll_scp_clk" [get_ports "PADS_CPU_JTAG_TDI PADS_CPU_JTAG_TDO"] -add
set_output_delay  [ expr $SCP_PERIOD* ($DELAY/100.0) ] -clock "pll_scp_clk" [get_ports "PADS_CPU_JTAG_TDO"] -add
#set_input_delay   [ expr $SCP_PERIOD* ($DELAY/100.0) ] -clock "pll_scp_clk" [get_ports "PADS_LSP_JTAG_TDI"] -add
set_output_delay  [ expr $SCP_PERIOD* ($DELAY/100.0) ] -clock "pll_scp_clk" [get_ports "PADS_LSP_JTAG_TDO"] -add

set_input_delay   [ expr $SCP_PERIOD*2 * ($DELAY/100.0) ] -clock "clk_to_lowspeed" [get_ports "PADS_EC_SDA PADS_EC_SCL PADS_EC_ADDR_HBIT"] -add
set_output_delay  [ expr $SCP_PERIOD*2 * ($DELAY/100.0) ] -clock "clk_to_lowspeed" [get_ports "PADS_EC_SDA PADS_EC_SCL PADS_EC_ADDR_HBIT"] -add



set_multicycle_path -from  [get_ports "PADS_EC_SDA PADS_EC_SCL PADS_EC_ADDR_HBIT"] -setup 2 -start 
set_multicycle_path -from  [get_ports "PADS_EC_SDA PADS_EC_SCL PADS_EC_ADDR_HBIT"] -hold  1 -start
set_multicycle_path -to    [get_ports "PADS_EC_SDA PADS_EC_SCL PADS_EC_ADDR_HBIT"] -setup 2 -end
set_multicycle_path -to    [get_ports "PADS_EC_SDA PADS_EC_SCL PADS_EC_ADDR_HBIT"] -hold  1 -end



set_input_delay   [ expr $SCP_PERIOD* ($DELAY/100.0) ] -clock "pll_scp_clk" [get_ports "PADS_PM*_ALERT PADS_PM*_CTRL PADS_PM*_SDA PADS_PM*_SCL"] -add
set_output_delay  [ expr $SCP_PERIOD* ($DELAY/100.0) ] -clock "pll_scp_clk" [get_ports "PADS_PM*_ALERT PADS_PM*_CTRL PADS_PM*_SDA PADS_PM*_SCL"] -add



set_multicycle_path -from  [get_ports "PADS_PM*_ALERT PADS_PM*_SDA PADS_PM*_SCL "] -setup 2 -start 
set_multicycle_path -from  [get_ports "PADS_PM*_ALERT PADS_PM*_SDA PADS_PM*_SCL "] -hold  1 -start
set_multicycle_path -to    [get_ports "PADS_PM*_ALERT PADS_PM*_CTRL  PADS_PM*_SDA PADS_PM*_SCL "] -setup 2 -end
set_multicycle_path -to    [get_ports "PADS_PM*_ALERT PADS_PM*_CTRL  PADS_PM*_SDA PADS_PM*_SCL "] -hold  1 -end



set_input_delay  [expr ${REFCLK_PERIOD}*($DELAY/100.0)]    -clock "ref_clk"              [get_ports "PADS_UART*"] -add
set_output_delay [expr ${REFCLK_PERIOD}*($DELAY/100.0)]    -clock "ref_clk"              [get_ports "PADS_UART*"] -add
set_input_delay   [ expr $SCP_PERIOD * ($DELAY/100.0) ]    -clock "pll_scp_clk"          [get_ports "PADS_UART*"] -add
set_output_delay  [ expr $SCP_PERIOD * ($DELAY/100.0) ]    -clock "pll_scp_clk"          [get_ports "PADS_UART*"] -add



                                                           
set_input_delay  [expr ${SCP_PERIOD}*2*($DELAY/100.0)]     -clock "clk_to_lowspeed"      [get_ports "PADS_GPIO*"] -add
set_output_delay [expr ${SCP_PERIOD}*2*($DELAY/100.0)]     -clock "clk_to_lowspeed"      [get_ports "PADS_GPIO*"] -add
set_input_delay  [expr ${REFCLK_PERIOD}*8*($DELAY/100.0)]  -clock "gpio_ref_clk_2"       [get_ports "PADS_GPIO*"] -add
set_multicycle_path -from  [get_ports "PADS_GPIO*"] -setup 2 -start 
set_multicycle_path -from  [get_ports "PADS_GPIO*"] -hold  1 -start
set_multicycle_path -to  [get_ports "PADS_GPIO*"] -setup 2 -start 
set_multicycle_path -to  [get_ports "PADS_GPIO*"] -hold  1 -start

# CLK_QSPI_PAD is 8ns period. 
# PADS_FLASH_* captured by clk_to_lowspeed(4ns)
set_input_delay  [expr $SCP_PERIOD*4 * ($DELAY/100.0) ]  -clock "CLK_QSPI_PAD" [get_ports "PADS_FLASH_CS PADS_FLASH_HOLD PADS_FLASH_MISO PADS_FLASH_MOSI PADS_FLASH_WP"] -add 

# PADS_FLASH_* launched by CLK_QSPI_PAD(8ns)
set_output_delay [expr $SCP_PERIOD*4 * ($DELAY/100.0) ]  -clock "CLK_QSPI_PAD" [get_ports "PADS_FLASH_CS PADS_FLASH_HOLD PADS_FLASH_MISO PADS_FLASH_MOSI PADS_FLASH_WP"] -add 





set_input_delay [expr $REFCLK_PERIOD * ($DELAY/100.0) ] -clock "ref_clk"      [get_ports " PADS_PWM_INPUT0  PADS_PWM_INPUT1"]  -add
set_input_delay [ expr $SCP_PERIOD * ($DELAY/100.0) ]   -clock "pll_scp_clk"  [get_ports " PADS_PWM_INPUT0  PADS_PWM_INPUT1"] -add

set_output_delay [expr $REFCLK_PERIOD * ($DELAY/100.0) ] -clock "ref_clk"      [get_ports "PADS_PWM_FAN  PADS_PWM_VID "]  -add
set_output_delay [ expr $SCP_PERIOD * ($DELAY/100.0) ]   -clock "pll_scp_clk"  [get_ports "PADS_PWM_FAN  PADS_PWM_VID "] -add

set_input_delay   [ expr $SCP_PERIOD * ($DELAY/100.0) ]  -clock "pll_scp_clk" [get_ports "PADS_SECURE_BOOT PADS_BOOT_SEL"] -add
set_output_delay  [ expr $SCP_PERIOD * ($DELAY/100.0) ]  -clock "pll_scp_clk" [get_ports "PADS_SECURE_BOOT PADS_BOOT_SEL"] -add

set_input_delay    [expr ${SCP_PERIOD}*($DELAY/100.0)]        -clock "pll_scp_clk" [get_ports "PADS_RESETN*"] -add
set_output_delay   [expr ${SCP_PERIOD}*($DELAY/100.0)]        -clock "pll_scp_clk" [get_ports "PADS_RESETN*"] -add

set_input_delay    [expr ${REFCLK_PERIOD}*($DELAY/100.0)]     -clock "ref_clk"     [get_ports "PADS_REF_CLK"] -add

set_input_delay   [expr ${SCP_PERIOD}*($DELAY/100.0)]         -clock "pll_scp_clk" [get_ports " PADS_CLKREQ*_N*"] -add
set_output_delay  [expr ${SCP_PERIOD}*($DELAY/100.0)]         -clock "pll_scp_clk" [get_ports " PADS_CLKREQ*_N*"] -add





# input/output port

## reset
set_output_delay  -clock "audio0_a_clk"          [expr ${AUDIO_PERIOD}*($DELAY/100.0)] [get_ports "audio0_a_rstn" -filter "port_direction =~ out"] -add
set_output_delay  -clock "audio0_b_clk"          [expr ${AUDIO_PERIOD}*($DELAY/100.0)] [get_ports "audio0_b_rstn" -filter "port_direction =~ out"] -add
set_output_delay  -clock "audio1_a_clk"          [expr ${AUDIO_PERIOD}*($DELAY/100.0)] [get_ports "audio1_a_rstn" -filter "port_direction =~ out"] -add
set_output_delay  -clock "audio1_b_clk"          [expr ${AUDIO_PERIOD}*($DELAY/100.0)] [get_ports "audio1_b_rstn" -filter "port_direction =~ out"] -add
set_output_delay  -clock "audio2_a_clk"          [expr ${AUDIO_PERIOD}*($DELAY/100.0)] [get_ports "audio2_a_rstn" -filter "port_direction =~ out"] -add
set_output_delay  -clock "audio2_b_clk"          [expr ${AUDIO_PERIOD}*($DELAY/100.0)] [get_ports "audio2_b_rstn" -filter "port_direction =~ out"] -add
set_output_delay  -clock "cbus_noc_clk"          [expr ${CBUS_PERIOD}*($DELAY/100.0)] [get_ports "cbus_noc_sync_rstn" -filter "port_direction =~ out"] -add
set_output_delay  -clock "dbus_noc_clk"          [expr ${DBUS_PERIOD}*($DELAY/100.0)] [get_ports "dbus_noc_sync_rstn" -filter "port_direction =~ out"] -add
set_output_delay  -clock "ref_clk"          [expr ${REFCLK_PERIOD}*($DELAY/100.0)] [get_ports "por_rst_n por_rst_n_to_pcie" -filter "port_direction =~ out"] -add
set_output_delay  -clock "tcu_clk"          [expr ${DBUS_PERIOD}*($DELAY/100.0)] [get_ports "tcu_rstn" -filter "port_direction =~ out"] -add
set_output_delay  -clock "mbist_repair_clk"          [expr ${SCP_PERIOD}*4*($DELAY/100.0)] [get_ports "pre_rstn_* tvsensor_*_ip_pre_rstn reg_pin_vga_misc_fm_noc_4_ slc0_misc_from_noc_0_" -filter "port_direction =~ out"] -add
set_output_delay  -clock "ref_clk"          [expr ${REFCLK_PERIOD}*($DELAY/100.0)] [get_ports "pre_rstn_* tvsensor_*_ip_pre_rstn reg_pin_vga_misc_fm_noc_4_ slc0_misc_from_noc_0_" -filter "port_direction =~ out"] -add

set_input_delay   -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "pcie_o_hot_resetn trig_pcie_button_from_pcie" -filter "port_direction =~ in"] -add
set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "pre_rstn_* por_rst_n_to_pcie  tvsensor_*_ip_pre_rstn" -filter "port_direction =~ out"] -add 



## adb bus
set_input_delay   -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "scp_dbus_*sync scp_cbus_*sync scp_apb_*sync " -filter "port_direction =~ in"] -add
set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "scp_dbus_*sync scp_cbus_*sync scp_apb_*sync " -filter "port_direction =~ out"] -add 

set_input_delay   -clock "clk_to_lowspeed"          [expr ${SCP_PERIOD}*2*($DELAY/100.0)] [get_ports "scp_jtag2axi_*sync " -filter "port_direction =~ in"] -add
set_output_delay  -clock "clk_to_lowspeed"          [expr ${SCP_PERIOD}*2*($DELAY/100.0)] [get_ports "scp_jtag2axi_*sync " -filter "port_direction =~ out"] -add 


## scp reg
set_input_delay   -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "reg_* trig_reg_* *_misc_*  gpu_state  audio*_idle " -filter "port_direction =~ in"] -add
set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "reg_* trig_reg_* *_misc_*  gpu_state  audio*_idle " -filter "port_direction =~ out"] -add 


## from/to pin_mux
set_input_delay   -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*_bist_* *_monitor* gpio_*put_* *uart_tx* *uart_rx* pcie_clkreq_*" -filter "port_direction =~ in"] -add
set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*_bist_* *_monitor* gpio_*put_* *uart_tx* *uart_rx* pcie_clkreq_*" -filter "port_direction =~ out"] -add 

set_input_delay   -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*_monitor_*" -filter "port_direction =~ in"] -add
#set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*_monitor_*" -filter "port_direction =~ out"] -add 

set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "hw_rstn_from_io_to_pcie" -filter "port_direction =~ out"] -add 




## iso/mbist
set_input_delay   -clock "mbist_repair_clk"          [expr ${SCP_PERIOD}*4*($DELAY/100.0)] [get_ports "ctrl_pm_*_off mbist_enable_* " -filter "port_direction =~ in"] -add
set_output_delay  -clock "mbist_repair_clk"          [expr ${SCP_PERIOD}*4*($DELAY/100.0)] [get_ports "mbist_repair_busy " -filter "port_direction =~ out"] -add

## ready
set_input_delay   -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*ready*" -filter "port_direction =~ in"] -add
#set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*ready*" -filter "port_direction =~ out"] -add 


## intrupt
set_input_delay   -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*_int* *_intr* *_irpt *_irq*" -filter "port_direction =~ in"] -add
set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*_int* *_intr* *_irpt *_irq*" -filter "port_direction =~ out"] -add 

set_output_delay  -clock "gpio_ref_clk_2"          [expr ${REFCLK_PERIOD}*8*($DELAY/100.0)] [get_ports "lowspeed_gpio_intr" -filter "port_direction =~ out"] -add


## ddrc
set_input_delay   -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*_ddrc_*" -filter "port_direction =~ in"] -add
set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] [get_ports "*_ddrc_*" -filter "port_direction =~ out"] -add 




## input/output port
#set redundant_port [get_ports " \
#audio*_*_rstn \
#ctrl_pm_*_off \
#mbist_enable_* \
#por_rst_n \
#tcu_rstn \
#dbus_noc_sync_rstn \
#cbus_noc_sync_rstn \
#pcie_phy_refclk \
#"]
#
#set scp_clk_inports [remove_from_collection [get_port "*" -filter "port_direction =~ in"] $redundant_port]
#set scp_clk_outports [remove_from_collection [get_port "*" -filter "port_direction =~ out"] $redundant_port]
#
#set_input_delay   -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] $scp_clk_inports -add
#set_output_delay  -clock "pll_scp_clk"          [expr ${SCP_PERIOD}*($DELAY/100.0)] $scp_clk_outports -add  



set_max_delay 37.5 -from [get_pins $low_speed_hier/efuse_wrap_u/efuse_4kb_u*/STROBE] -to [get_pins $low_speed_hier/efuse_wrap_u/efuse_4kb_u*/Q*] -ignore_clock_latency


#set_max_delay 7.1 -to   [get_pins "$low_speed_hier/efuse_wrap_u/efuse_4kb_u*/*"] -ignore_clock_latency
#set_min_delay 0 -to   [get_pins "$low_speed_hier/efuse_wrap_u/efuse_4kb_u*/*"] -ignore_clock_latency

set_false_path -to   [get_pins "$low_speed_hier/efuse_wrap_u/efuse_4kb_u*/*"] 
set_false_path -to   [get_pins "$low_speed_hier/efuse_wrap_u/efuse_4kb_u*/*"] 


#pll bypass reg
set_multicycle_path -from [get_cells "$scp_top_hier/scp_reg_top_inst/scp_reg_inst/inter_*_reg*" -filter "full_name !~ *inter_pads*"] -setup 2 -start
set_multicycle_path -from [get_cells "$scp_top_hier/scp_reg_top_inst/scp_reg_inst/inter_*_reg*" -filter "full_name !~ *inter_pads*"] -hold 1 -start
##register to pads
set_multicycle_path -from [get_cells "$scp_top_hier/scp_reg_top_inst/scp_reg_inst/inter_pads_*"] -setup 4 -start
set_multicycle_path -from [get_cells "$scp_top_hier/scp_reg_top_inst/scp_reg_inst/inter_pads_*"] -hold 3 -start


#set_data_check -from PADS_EC_SCL -to PADS_EC_SDA -setup 2.1 
#set_data_check -from PADS_EC_SCL -to PADS_EC_SDA -hold 2.1 
#set_data_check -from PADS_PM0_SCL -to PADS_PM0_SDA -setup 2.1 
#set_data_check -from PADS_PM0_SCL -to PADS_PM0_SDA -hold 2.1 
#set_data_check -from PADS_PM1_SCL -to PADS_PM1_SDA -setup 2.1 
#set_data_check -from PADS_PM1_SCL -to PADS_PM1_SDA -hold 2.1
