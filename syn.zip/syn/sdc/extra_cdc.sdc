set scp_top_hier  scp_top_inst

set_disable_clock_gating_check [get_pins "$scp_top_hier/clk_gen_inst/clock_freq_measure_inst/pll_detect_clk_sel_u/cell_clk_or*_u*/dont_touch_clk_or_u/*"]
set_disable_clock_gating_check [get_pins "$scp_top_hier/clk_gen_inst/clk_switch_inst_clk_switch*/clk_switch_u*/clk_out_cell/dont_touch_clk_or_u/B"]
set_disable_clock_gating_check [get_pins "$scp_top_hier/clk_gen_inst/clk_switch_inst_clk_switch2_pll_others_clkout_inst/clk_out_cell/dont_touch_clk_or_u/B"]
set_disable_clock_gating_check [get_pins "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_*/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/B"]
set_disable_clock_gating_check [get_pins "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_*/clk_switch_pll_bypass0/clk_out_cell/dont_touch_clk_or_u/B"]

# pll out1
set pll_names "audio_a audio_b databus dma frac_dummy gddr gpua gpub pdp vdec_bclk vdec_cclk venc_cclk vga"
foreach pll_name $pll_names {
  set_clock_exclusivity -type user_defined -output "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_${pll_name}/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/Y" -input "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_${pll_name}/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/A $scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_${pll_name}/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/B"
}
# pll out2
set pll_names "pcie scp"
foreach pll_name $pll_names {
  set_clock_exclusivity -type user_defined -output "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_${pll_name}/clk_switch_pll_bypass0/clk_out_cell/dont_touch_clk_or_u/Y" -input "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_${pll_name}/clk_switch_pll_bypass0/clk_out_cell/dont_touch_clk_or_u/A $scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_${pll_name}/clk_switch_pll_bypass0/clk_out_cell/dont_touch_clk_or_u/B"
  set_clock_exclusivity -type user_defined -output "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_${pll_name}/clk_switch_pll_bypass1/clk_out_cell/dont_touch_clk_or_u/Y" -input "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_${pll_name}/clk_switch_pll_bypass1/clk_out_cell/dont_touch_clk_or_u/A $scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_${pll_name}/clk_switch_pll_bypass1/clk_out_cell/dont_touch_clk_or_u/B"
}
