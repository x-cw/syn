# sdc_start
#PLL clock
#set GPU_PERIOD                    [expr 1000.0 / 950 ]
set GPU_PERIOD                    [expr 1000.0 / 1000 ]
set GDDR_PERIOD                   [expr 1000.0 / 1200 ]
set PCIE_PERIOD                   [expr 1000.0 / 800  ]
#set DMA_PERIOD                    [expr 1000.0 / 700  ]
set DMA_PERIOD                    1.428
#set VDEC_BCLK_PERIOD              [expr 1000.0 / 650  ]
#set VDEC_CCLK_PERIOD              [expr 1000.0 / 650  ]
#set VENC_CCLK_PERIOD              [expr 1000.0 / 650  ]
set VDEC_BCLK_PERIOD              1.538
set VDEC_CCLK_PERIOD              1.538
set VENC_CCLK_PERIOD              [expr 1000.0 / 800 ]
set PDP_PERIOD                    [expr 1000.0 / 800 ]
set EFUSE_PERIOD                  [expr 1000.0 / 1000 ]
set DBUS_PERIOD                   [expr 1000.0 / 1000 ]
set CBUS_PERIOD                   [expr 1000.0 / 250  ]
set SCP_PERIOD                    [expr 1000.0 / 500  ]
#set VGA_PERIOD                    [expr 1000.0 / 600  ]
set VGA_PERIOD                    1.666
set AUDIO_PERIOD                  [expr 1000.0 / 100  ]
set FRAC_DUMMY_PERIOD             [expr 1000.0 / 1000  ]



set PCIE_PHY_PERIOD               [expr 1000.0 / 100  ]
#set PCIE_PHY_333M_PERIOD               [expr 1000.0 / 333  ]
#set PCIE_PHY_1G_PERIOD               [expr 1000.0 / 1000  ]
#set PCIE_PHY_2G_PERIOD               [expr 1000.0 / 2000  ]

#ref and pinmux clock
set REFCLK_PERIOD                 [expr 1000.0 / 50   ]
set CLK_TS_PERIOD                 [expr 1000.0 / 50   ]
#set IP_TEST_PERIOD               [expr 1000.0 / 10  ]
set DELAY 60
set LOW_DELAY 40

set clk_gen_hier  scp_top_inst/clk_gen_inst
set scp_top_hier  scp_top_inst
set low_speed_hier  low_speed_misc_wrap_inst
set reset_ctrl_hier scp_top_inst/reset_ctrl_inst
set trust_engine_hier trust_engine_wrapper_inst


#todo driving cell
#set_driving_cell -lib_cell  BUF_D4_N_S7P94TL_C60L06 -pin Y -no_design_rule [all_inputs]


#set_input_transition -max 1  [get_ports PADS* -filter "port_direction =~ in || port_direction =~ inout"]
#set_input_transition -min 0.1  [get_ports PADS* -filter "port_direction =~ in || port_direction =~ inout"]
#set_load -max 20  [get_ports PADS*]
#set_load -min 2  [get_ports PADS*]





##function mode
set_case_analysis 0 [get_ports "PADS_MODE*"]
#TODO
#set_case_analysis 0 [get_pins scp_top_inst/gp3_io_inst/u_gp3_pad/dont_touch_block_pads_inst1/gp3_pad_sps]
#set_ideal_network -no_propagate [get_ports "*rstn* *reset* trig_pcie*_button"]


#################################source clock###################
create_clock -name "pll_gpua_clk"       -period "$GPU_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_gpua/inno_pll_frac_inst/clko0"]
create_clock -name "pll_gpub_clk"       -period "$GPU_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_gpub/inno_pll_frac_inst/clko0"]
create_clock -name "pll_gddr_clk"       -period "$GDDR_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_gddr/inno_pll_frac_inst/clko0"]
create_clock -name "pll_pcie_clk"        -period "$PCIE_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_pcie/inno_pll_frac_inst/clko0"]
create_clock -name "pll_pcie_phy_clk"    -period "$PCIE_PHY_PERIOD"      [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_pcie/inno_pll_frac_inst/clko1"]
create_clock -name "pll_dma_clk"        -period "$DMA_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_dma/inno_pll_frac_inst/clko0"]
create_clock -name "pll_vdec_bclk"     -period "$VDEC_BCLK_PERIOD"     [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_vdec_bclk/inno_pll_frac_inst/clko0"]
create_clock -name "pll_vdec_cclk"     -period "$VDEC_CCLK_PERIOD"        [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_vdec_cclk/inno_pll_frac_inst/clko0"]
create_clock -name "pll_venc_cclk"     -period "$VENC_CCLK_PERIOD"        [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_venc_cclk/inno_pll_frac_inst/clko0"]
create_clock -name "pll_pdp_clk"       -period "$PDP_PERIOD"            [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_pdp/inno_pll_frac_inst/clko0"]
create_clock -name "pll_databus_clk"    -period "$DBUS_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_databus/inno_pll_frac_inst/clko0"]
#create_clock -name "pll_cfgbus_clk"     -period "$CBUS_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_cfgbus/inno_pll_frac_inst/clko0"]
create_clock -name "pll_efuse_clk"     -period "$EFUSE_PERIOD"          [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_scp/inno_pll_frac_inst/clko0"]
create_clock -name "pll_scp_clk"        -period "$SCP_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_scp/inno_pll_frac_inst/clko1"]
create_clock -name "pll_vga_clk"        -period "$VGA_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_vga/inno_pll_frac_inst/clko0"]
create_clock -name "pll_audio_a_clk"        -period "$AUDIO_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_a/inno_pll_frac_inst/clko0"]
create_clock -name "pll_audio_b_clk"        -period "$AUDIO_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_b/inno_pll_frac_inst/clko0"]
#create_clock -name "pll_int_dummy_clk"  -period "$INT_DUMMY_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_int_dummy/inno_pll_frac_inst/clko0"]
create_clock -name "pll_frac_dummy_clk"  -period "$FRAC_DUMMY_PERIOD"           [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_frac_dummy/inno_pll_frac_inst/clko0"]

create_clock -name "ref_clk"            -period $REFCLK_PERIOD          [get_pins "$clk_gen_hier/PADS_REF_CLK_inst/Y"]

#TODO function  mode have no clock
create_clock -name "LSP_JTAG_CLK" [get_pins "$scp_top_hier/g2_io_inst/u_g2_pad/pads_lsp_jtag_tclk_inst/Y"]    -period "${CLK_TS_PERIOD}" 
create_clock -name "CPU_JTAG_CLK" [get_pins "$scp_top_hier/g2_io_inst/u_g2_pad/pads_cpu_jtag_tclk_inst/Y"]  -period "${CLK_TS_PERIOD}"




##################################generate clock###################
create_generated_clock -name CLK_POR_0  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_0_/Q ] -divide_by 2 -source [get_pins $clk_gen_hier/PADS_REF_CLK_inst/Y]
create_generated_clock -name CLK_POR_1  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_1_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_0_/Q]
create_generated_clock -name CLK_POR_2  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_2_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_1_/Q]
create_generated_clock -name CLK_POR_3  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_3_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_2_/Q]
create_generated_clock -name CLK_POR_4  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_4_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_3_/Q]
create_generated_clock -name CLK_POR_5  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_5_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_4_/Q]
create_generated_clock -name CLK_POR_6  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_6_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_5_/Q]
create_generated_clock -name CLK_POR_7  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_7_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_6_/Q]
create_generated_clock -name CLK_POR_8  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_8_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_7_/Q]
create_generated_clock -name CLK_POR_9  [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_9_/Q ] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_8_/Q]
create_generated_clock -name CLK_POR_10 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_10_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_9_/Q]
create_generated_clock -name CLK_POR_11 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_11_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_10_/Q]
create_generated_clock -name CLK_POR_12 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_12_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_11_/Q]
create_generated_clock -name CLK_POR_13 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_13_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_12_/Q]
create_generated_clock -name CLK_POR_14 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_14_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_13_/Q]
create_generated_clock -name CLK_POR_15 [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_15_/Q] -divide_by 2 -source [get_pins $scp_top_hier/reset_ctrl_inst/scp_por_inst/clk_div_pre_reg_14_/Q]

#freq_div


create_generated_clock -name "mbist_repair_clk"   [get_pins "$clk_gen_hier/freq_div_inst_mbist_repair_clk_div4_inst/fout_pre_reg/Q"] -divide_by 4 -add -master_clock "ref_clk"        -source [get_pins "$clk_gen_hier/PADS_REF_CLK_inst/Y"]
create_generated_clock -name "dft_test_clk_300m"   [get_pins "$clk_gen_hier/freq_div_inst_dft_test_clk_300m_div2_inst/fout_pre_reg/Q"] -divide_by 2 -add -master_clock "pll_vga_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_vga/inno_pll_frac_inst/clko0"]
create_generated_clock -name "dft_apb_clk"        [get_pins "$clk_gen_hier/freq_div_inst_pll_dft_apb_clk_div4_inst/fout_pre_reg/Q"]  -divide_by 4 -add -master_clock "ref_clk"        -source [get_pins "$clk_gen_hier/PADS_REF_CLK_inst/Y"]
create_generated_clock -name "pdp_div_clk_400m"   [get_pins "$clk_gen_hier/freq_div_inst_pdp_div_clk_400m_div2_inst/fout_pre_reg/Q"] -divide_by 2 -add -master_clock "pll_pdp_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_pdp/inno_pll_frac_inst/clko0"]
create_generated_clock -name "hdmi_timclk"   [get_pins "$clk_gen_hier/freq_div_inst_hdmi_timclk_200m_div2_inst/fout_pre_reg/Q"] -divide_by 2 -add -master_clock "pdp_div_clk_400m"        -source [get_pins "$clk_gen_hier/freq_div_inst_pdp_div_clk_400m_div2_inst/fout_pre_reg/Q"]

create_generated_clock -name "gpua_test_clk" [get_pins "$clk_gen_hier/freq_div_inst_pll_gpua_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_gpua_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_gpua/inno_pll_frac_inst/clko0"]
create_generated_clock -name "gpub_test_clk" [get_pins "$clk_gen_hier/freq_div_inst_pll_gpub_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_gpub_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_gpub/inno_pll_frac_inst/clko0"]
create_generated_clock -name "gddr_test_clk" [get_pins "$clk_gen_hier/freq_div_inst_pll_gddr_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_gddr_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_gddr/inno_pll_frac_inst/clko0"]
create_generated_clock -name "pcie_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_pcie_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_pcie_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_pcie/inno_pll_frac_inst/clko0"]
create_generated_clock -name "dma_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_dma_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_dma_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_dma/inno_pll_frac_inst/clko0"]
create_generated_clock -name "vdec_bclk_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_vdec_bclk_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_vdec_bclk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_vdec_bclk/inno_pll_frac_inst/clko0"]
create_generated_clock -name "vdec_cclk_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_vdec_cclk_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_vdec_cclk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_vdec_cclk/inno_pll_frac_inst/clko0"]
create_generated_clock -name "venc_cclk_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_venc_cclk_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_venc_cclk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_venc_cclk/inno_pll_frac_inst/clko0"]
create_generated_clock -name "pdp_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_pdp_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_pdp_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_pdp/inno_pll_frac_inst/clko0"]
create_generated_clock -name "efuse_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_efuse_test_clk_div_n/fout_pre_reg/Q"]   -divide_by 32 -add -master_clock "pll_efuse_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_scp/inno_pll_frac_inst/clko0"]
#create_generated_clock -name "cfgbus_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_cfgbus_test_clk_div_n/fout_pre_reg/Q"]   -divide_by 32 -add -master_clock "pll_cfgbus_clk" -source  [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_cfgbus/inno_pll_frac_inst/clko0"]
create_generated_clock -name "databus_test_clk" [get_pins "$clk_gen_hier/freq_div_inst_pll_databus_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_databus_clk" -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_databus/inno_pll_frac_inst/clko0"]
create_generated_clock -name "scp_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_scp_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_scp_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_scp/inno_pll_frac_inst/clko1"]
create_generated_clock -name "vga_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_vga_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_vga_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_vga/inno_pll_frac_inst/clko0"]
create_generated_clock -name "audio_a_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_audio_a_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_audio_a_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_a/inno_pll_frac_inst/clko0"]
create_generated_clock -name "audio_b_test_clk"  [get_pins "$clk_gen_hier/freq_div_inst_pll_audio_b_test_clk_div_n/fout_pre_reg/Q"]  -divide_by 32 -add -master_clock "pll_audio_b_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_b/inno_pll_frac_inst/clko0"]
create_generated_clock -name "pcie_phy_test_clk" [get_pins "$clk_gen_hier/freq_div_inst_pll_pcie_phy_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_pcie_phy_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_pcie/inno_pll_frac_inst/clko1"]
#create_generated_clock -name "int_dummy_test_clk" [get_pins "$clk_gen_hier/freq_div_inst_pll_int_dummy_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_int_dummy_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_int_dummy/inno_pll_frac_inst/clko0"]
create_generated_clock -name "frac_dummy_test_clk" [get_pins "$clk_gen_hier/freq_div_inst_pll_frac_dummy_test_clk_div_n/fout_pre_reg/Q"] -divide_by 32 -add -master_clock "pll_frac_dummy_clk"  -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_frac_dummy/inno_pll_frac_inst/clko0"]


create_generated_clock -name "cfgbus_clk"        [get_pins "$clk_gen_hier/freq_div_inst_cfgbus_clk_div2_inst/fout_pre_reg/Q"]  -divide_by 2 -add -master_clock "pll_scp_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_scp/inno_pll_frac_inst/clko1"]

create_generated_clock -name "clk_to_lowspeed"        [get_pins "$clk_gen_hier/freq_div_inst_freq_div_2n_lowspeed/fout_pre_reg/Q"]  -divide_by 2 -add -master_clock "pll_scp_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_scp/inno_pll_frac_inst/clko1"]

create_generated_clock -name "clk_to_rom"        [get_pins "$clk_gen_hier/freq_div_inst_freq_div_2n_rom/fout_pre_reg/Q"]  -divide_by 2 -add -master_clock "pll_scp_clk"        -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_scp/inno_pll_frac_inst/clko1"]

create_generated_clock -name "gpio_ref_clk_0"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst_freq_div_2n_gpio_db_ref_clk_inst0/fout_pre_reg/Q ] -divide_by 2 -source [get_pins $clk_gen_hier/PADS_REF_CLK_inst/Y]
create_generated_clock -name "gpio_ref_clk_1"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst_freq_div_2n_gpio_db_ref_clk_inst1/fout_pre_reg/Q ] -divide_by 2 -source [get_pins  $scp_top_hier/clk_gen_inst/freq_div_inst_freq_div_2n_gpio_db_ref_clk_inst0/fout_pre_reg/Q ]
create_generated_clock -name "gpio_ref_clk_2"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst_freq_div_2n_gpio_db_ref_clk_inst2/fout_pre_reg/Q ] -divide_by 2 -source [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst_freq_div_2n_gpio_db_ref_clk_inst1/fout_pre_reg/Q]


create_generated_clock -name "ec_ref_clk_0"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst_freq_div_2n_ec_db_ref_clk_inst0/fout_pre_reg/Q ] -divide_by 2 -source [get_pins $clk_gen_hier/PADS_REF_CLK_inst/Y]
create_generated_clock -name "ec_ref_clk_1"  [get_pins $scp_top_hier/clk_gen_inst/freq_div_inst_freq_div_2n_ec_db_ref_clk_inst1/fout_pre_reg/Q ] -divide_by 2 -source [get_pins  $scp_top_hier/clk_gen_inst/freq_div_inst_freq_div_2n_ec_db_ref_clk_inst0/fout_pre_reg/Q ]




create_generated_clock -name "qspi_clk" [get_pins "$low_speed_hier/qspi_wrapper_u/DWC_ssi_inst/U_sclkgen/sclk_out_reg/Q"] -divide_by 2 -add -master_clock "clk_to_lowspeed"  -source [get_pins "$clk_gen_hier/freq_div_inst_freq_div_2n_lowspeed/fout_pre_reg/Q"]


create_generated_clock -name "CLK_QSPI_PAD" [get_pins "$scp_top_hier/g2_io_inst/u_g2_pad/pads_flash_clk_inst/PAD"] -add -master_clock "qspi_clk" -divide_by 1 -source [get_pins "$low_speed_hier/qspi_wrapper_u/DWC_ssi_inst/U_sclkgen/sclk_out_reg/Q"]





# CRM
create_generated_clock -name "dbus_noc_clk"  [get_pins "$reset_ctrl_hier/crm_inst_noc_crm_dbus_noc/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_databus_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_databus/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "cbus_noc_clk"  [get_pins "$reset_ctrl_hier/crm_inst_noc_crm_cbus_noc/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "cfgbus_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/freq_div_inst_cfgbus_clk_div2_inst/fout_pre_reg/Q"] 
create_generated_clock -name "tcu_clk"  [get_pins "$reset_ctrl_hier/crm_inst_noc_crm_tcu/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_databus_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_databus/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio0_a_clk"  [get_pins "$reset_ctrl_hier/crm_inst_noc_crm_audio0_a/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_a_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_a/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio0_b_clk"  [get_pins "$reset_ctrl_hier/crm_inst_noc_crm_audio0_b/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_b_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_b/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio1_a_clk"  [get_pins "$reset_ctrl_hier/crm_inst_noc_crm_audio1_a/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_a_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_a/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio1_b_clk"  [get_pins "$reset_ctrl_hier/crm_inst_noc_crm_audio1_b/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_b_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_b/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio2_a_clk"  [get_pins "$reset_ctrl_hier/crm_inst_noc_crm_audio2_a/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_a_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_a/inno_pll_frac_inst/clko0"] 
create_generated_clock -name "audio2_b_clk"  [get_pins "$reset_ctrl_hier/crm_inst_noc_crm_audio2_b/md_clk_buf_u/dont_touch_clk_buf_u/Y"]      -add -master_clock "pll_audio_b_clk" \
        -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_audio_b/inno_pll_frac_inst/clko0"] 





#############others
create_generated_clock -name CLK_PLL_DETECT_DEST [get_pins $clk_gen_hier/clock_freq_measure_inst/pll_detect_clk_sel_u/cell_clk_or4_u4/dont_touch_clk_or_u/Y]  -master_clock "pll_databus_clk" -divide_by 1 -source [get_pins "$clk_gen_hier/pll_wrap_inst_pll_wrapper_databus/inno_pll_frac_inst/clko0"]




#####################switch stop
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_gpub_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_pll_gpu_ping_pong/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_gddr/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_pcie/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_dma/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_vdec_bclk/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_vdec_cclk/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_venc_cclk/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_pdp/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_efuse/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
#set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_cfgbus/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_databus/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_scp/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_vga/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_audio_a/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk pll_pcie_phy_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch3_audio_b/clk_switch_u1/clk_out_cell/dont_touch_clk_or_u/Y"]

set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk ref_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch2_pcie_phy/clk_out_cell/dont_touch_clk_or_u/Y"]


##phy clock for test and measure
set_sense -type clock -stop_propagation  -clocks  [get_clocks "pll_frac_dummy_clk pll_pcie_phy_clk pll_audio_b_clk"] [get_pins  "$clk_gen_hier/clk_switch_inst_clk_switch2_pll_others_clkout_inst/clk_out_cell/dont_touch_clk_or_u/Y"]
    

## pll clock switch
set_sense -type clock -stop_propagation  -clocks  [get_clocks "ref_clk"] [get_pins  "$clk_gen_hier/pll_wrap_inst_pll_wrapper_*/clk_switch_pll_bypass*/clk_out_cell/dont_touch_clk_or_u/Y"]

#set_clock_exclusivity -type user_defined -output "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_frac_dummy/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/Y" -input "$scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_frac_dummy/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/A $scp_top_hier/clk_gen_inst/pll_wrap_inst_pll_wrapper_frac_dummy/clk_switch_pll_bypass/clk_out_cell/dont_touch_clk_or_u/B"


set_clock_groups -allow_paths -asynchronous \
  -group [get_clocks "pll_gpua_clk"] \
  -group [get_clocks "pll_gpub_clk"] \
  -group [get_clocks "pll_gddr_clk "] \
  -group [get_clocks "pll_pcie_clk"] \
  -group [get_clocks "pll_dma_clk"] \
  -group [get_clocks "pll_vdec_bclk "] \
  -group [get_clocks "pll_vdec_cclk "] \
  -group [get_clocks "pll_venc_cclk "] \
  -group [get_clocks "pll_pdp_clk pdp_div_clk_400m hdmi_timclk"] \
  -group [get_clocks "pll_efuse_clk CLK_PLL_DETECT_DEST"] \
  -group [get_clocks "pll_databus_clk"] \
  -group [get_clocks "pll_scp_clk clk_to_lowspeed CLK_QSPI_PAD qspi_clk clk_to_rom"] \
  -group [get_clocks "cfgbus_clk"] \
  -group [get_clocks "pll_vga_clk"] \
  -group [get_clocks "pll_audio_a_clk"] \
  -group [get_clocks "pll_audio_b_clk"] \
  -group [get_clocks "pll_frac_dummy_clk"] \
  -group [get_clocks "ref_clk gpio_ref_clk_0 gpio_ref_clk_1 gpio_ref_clk_2 ec_ref_clk_0 ec_ref_clk_1"] \
  -group [get_clocks "pll_pcie_phy_clk"] \
  -group [get_clocks "LSP_JTAG_CLK "] \
  -group [get_clocks "CPU_JTAG_CLK"] \
  -group [get_clocks "CLK_POR_*"] \
  -group [get_clocks "pcie_phy_test_clk"] \
  -group [get_clocks "mbist_repair_clk"] \
  -group [get_clocks "dft_test_clk_300m"] \
  -group [get_clocks "dft_apb_clk"] \
  -group [get_clocks "gpua_test_clk"] \
  -group [get_clocks "gpub_test_clk"] \
  -group [get_clocks "gddr_test_clk"] \
  -group [get_clocks "pcie_test_clk"] \
  -group [get_clocks "dma_test_clk"] \
  -group [get_clocks "vdec_bclk_test_clk"] \
  -group [get_clocks "vdec_cclk_test_clk"] \
  -group [get_clocks "venc_cclk_test_clk"] \
  -group [get_clocks "pdp_test_clk"] \
  -group [get_clocks "efuse_test_clk"] \
  -group [get_clocks "databus_test_clk"] \
  -group [get_clocks "scp_test_clk"] \
  -group [get_clocks "vga_test_clk"] \
  -group [get_clocks "audio_a_test_clk"] \
  -group [get_clocks "audio_b_test_clk"] \
  -group [get_clocks "frac_dummy_test_clk"] \
  -group [get_clocks "dbus_noc_clk"] \
  -group [get_clocks "cbus_noc_clk"] \
  -group [get_clocks "tcu_clk"] \
  -group [get_clocks "audio0_a_clk"] \
  -group [get_clocks "audio0_b_clk"] \
  -group [get_clocks "audio1_a_clk"] \
  -group [get_clocks "audio1_b_clk"] \
  -group [get_clocks "audio2_a_clk"] \
  -group [get_clocks "audio2_b_clk"]  

# sdc_inout_start
